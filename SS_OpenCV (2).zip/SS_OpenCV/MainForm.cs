﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using Emgu.CV;
using Emgu.CV.Structure;
using ZedGraph;

namespace SS_OpenCV
{ 
    public partial class MainForm : Form
    {
        Image<Bgr, Byte> img = null; // working image
        Image<Bgr, Byte> imgUndo = null; // undo backup image - UNDO
        Image<Bgr, Byte> imgCopy = null; // copy image for translation and rotation
        string title_bak = "";

        public MainForm()
        {
            InitializeComponent();
            title_bak = Text;
        }

        /// <summary>
        /// Opens a new image
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                img = new Image<Bgr, byte>(openFileDialog1.FileName);
                Text = title_bak + " [" +
                        openFileDialog1.FileName.Substring(openFileDialog1.FileName.LastIndexOf("\\") + 1) +
                        "]";
                imgUndo = img.Copy();
                ImageViewer.Image = img.Bitmap;
                ImageViewer.Refresh();
            }
        }

        /// <summary>
        /// Saves an image with a new name
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                ImageViewer.Image.Save(saveFileDialog1.FileName);
            }
        }

        /// <summary>
        /// Closes the application
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// restore last undo copy of the working image
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (imgUndo == null) // verify if the image is already opened
                return; 
            Cursor = Cursors.WaitCursor;
            img = imgUndo.Copy();

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        /// <summary>
        /// Change visualization mode
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void autoZoomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // zoom
            if (autoZoomToolStripMenuItem.Checked)
            {
                ImageViewer.SizeMode = PictureBoxSizeMode.Zoom;
                ImageViewer.Dock = DockStyle.Fill;
            }
            else // with scroll bars
            {
                ImageViewer.Dock = DockStyle.None;
                ImageViewer.SizeMode = PictureBoxSizeMode.AutoSize;
            }
        }

        /// <summary>
        /// Show authors form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void autoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AuthorsForm form = new AuthorsForm();
            form.ShowDialog();
        }

        /// <summary>
        /// Calculate the image negative
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void negativeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();

            ImageClass.Negative(img);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        /// <summary>
        /// Call automated image processing check
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void evalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EvalForm eval = new EvalForm();
            eval.ShowDialog();
        }

        /// <summary>
        /// Call image convertion to gray scale
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void grayToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();

            ImageClass.ConvertToGray(img);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        private void RedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();

            ImageClass.RedChannel(img);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        private void greenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();

            ImageClass.GreenChannel(img);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        private void blueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();

            ImageClass.BlueChannel(img);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        private void ajusteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();

            InputBox form = new InputBox("Ajuste de Brilho e Contraste");

            form.label1.Text = "Brilho";
            form.label1.Visible = true;
            form.ValueTextBox.Visible = true;
            form.ValueTextBox.Text = "0";
            form.label2.Text = "Contraste";
            form.label2.Visible = true;
            form.ValueTextBox1.Visible = true;
            form.ValueTextBox1.Text = "1";

            form.ShowDialog();

            int brilho = Convert.ToInt32(form.ValueTextBox.Text);
            double contraste = Convert.ToDouble(form.ValueTextBox1.Text);

            if (brilho >= 0 && brilho <= 255)
            {
                if (contraste >= 0 && contraste <= 3)
                {
                    ImageClass.BrightContrast(img, brilho, contraste);
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Introduza um valor numérico para contraste entre 0 e 3", "Erro!");
                }
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Introduza um valor numérico para brilho entre 0 e 255", "Erro!");
            }

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        private void translationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();
            imgCopy = img.Copy();

            InputBox form = new InputBox("Translação");

            form.label1.Text = "Dx";
            form.label1.Visible = true;
            form.ValueTextBox.Visible = true;
            form.ValueTextBox.Text = "0";
            form.label2.Text = "Dy";
            form.label2.Visible = true;
            form.ValueTextBox1.Visible = true;
            form.ValueTextBox1.Text = "0";

            form.ShowDialog();

            int dx = Convert.ToInt32(form.ValueTextBox.Text);
            int dy = Convert.ToInt32(form.ValueTextBox1.Text);

            ImageClass.Translation(img, imgCopy, dx, dy);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        private void rotationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();
            imgCopy = img.Copy();

            InputBox form = new InputBox("Translação");

            form.label1.Text = "Angle";
            form.label1.Visible = true;
            form.ValueTextBox.Visible = true;
            form.ValueTextBox.Text = "0.0";
            form.label2.Text = "Dy";
            form.label2.Visible = false;
            form.ValueTextBox1.Visible = false;
            form.ValueTextBox1.Text = "0";

            form.ShowDialog();

            float angle = (float)(Convert.ToDouble(form.ValueTextBox.Text));
            //int dy = Convert.ToInt32(form.ValueTextBox1.Text);

            ImageClass.Rotation(img, imgCopy, angle);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        private void zoomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void normalZoomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();
            imgCopy = img.Copy();

            InputBox form = new InputBox("Zoom");

            form.label1.Text = "Scale";
            form.label1.Visible = true;
            form.ValueTextBox.Visible = true;
            form.ValueTextBox.Text = "1.0";
            form.label2.Text = "Dy";
            form.label2.Visible = false;
            form.ValueTextBox1.Visible = false;
            form.ValueTextBox1.Text = "0";

            form.ShowDialog();

            float scaleFactor = (float)(Convert.ToDouble(form.ValueTextBox.Text));
            //int dy = Convert.ToInt32(form.ValueTextBox1.Text);

            ImageClass.Scale(img, imgCopy, scaleFactor);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        int centerX; int centerY;
        bool mouseflag = false;

        private void xYZoomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();
            imgCopy = img.Copy();

            InputBox form = new InputBox("Zoom");

            form.label1.Text = "Scale";
            form.label1.Visible = true;
            form.ValueTextBox.Visible = true;
            form.ValueTextBox.Text = "1.0";
            form.label2.Text = "Dy";
            form.label2.Visible = false;
            form.ValueTextBox1.Visible = false;
            form.ValueTextBox1.Text = "0";

            form.ShowDialog();

            float scaleFactor = (float)(Convert.ToDouble(form.ValueTextBox.Text));
            //int dy = Convert.ToInt32(form.ValueTextBox1.Text);

            mouseflag = true;
            while (mouseflag)
                Application.DoEvents();

            ImageClass.Scale_point_xy(img, imgCopy, scaleFactor, centerX, centerY);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        private void meanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();
            imgCopy = img.Copy();

            ImageClass.Mean(img, imgCopy);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        private void ImageViewer_Click(object sender, EventArgs e)
        {

        }

        private void ImageViewer_MouseClick(object sender, MouseEventArgs e)
        {
            if (mouseflag)
            {
                centerX = e.X;
                centerY = e.Y;

                mouseflag = false;
            }
        }

        private void customFilterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 
            //copy Undo Image
            imgUndo = img.Copy();
            imgCopy = img.Copy();

            float ij00, ij01, ij02, ij10, ij11, ij12, ij20, ij21, ij22;

            FilterEditor form = new FilterEditor("Filtros");

            /*form.label1.Text = "Angle";
            form.label1.Visible = true;
            form.ValueTextBox.Visible = true;
            form.ValueTextBox.Text = "0.0";
            form.label2.Text = "Dy";
            form.label2.Visible = false;
            form.ValueTextBox1.Visible = false;
            form.ValueTextBox1.Text = "0";*/

            form.ShowDialog();



            float matrixWeight = (float)Convert.ToDouble(form.weight.Text);
            ij00 = (float)Convert.ToDouble(form.ij00.Text);
            ij01 = (float)Convert.ToDouble(form.ij01.Text);
            ij02 = (float)Convert.ToDouble(form.ij02.Text);
            ij10 = (float)Convert.ToDouble(form.ij10.Text);
            ij11 = (float)Convert.ToDouble(form.ij11.Text);
            ij12 = (float)Convert.ToDouble(form.ij12.Text);
            ij20 = (float)Convert.ToDouble(form.ij20.Text);
            ij21 = (float)Convert.ToDouble(form.ij21.Text);
            ij22 = (float)Convert.ToDouble(form.ij22.Text);


            float[,] matrix = new float[3, 3] { { ij00, ij01, ij02 }, { ij10, ij11, ij12 }, { ij20, ij21, ij22 } };

            ImageClass.NonUniform(img, imgCopy, matrix, matrixWeight);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        private void median3x3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();
            imgCopy = img.Copy();

            ImageClass.Median(img, imgCopy);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        private void grayScaleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 
            //copy Undo Image
            imgUndo = img.Copy();
            imgCopy = img.Copy();

            int[,] histogram = ImageClass.Histogram_All(img);

            Histograma form = new Histograma("Gray Scale Histogram", histogram, 0);

            form.ShowDialog();

            Cursor = Cursors.Default; // normal cursor

        }

        private void rGBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 
            //copy Undo Image
            imgUndo = img.Copy();
            imgCopy = img.Copy();

            int[,] histogram = ImageClass.Histogram_All(img);

            Histograma form = new Histograma("RGB Channels Histogram", histogram, 1);

            form.ShowDialog();

            Cursor = Cursors.Default; // normal cursor
        }

        private void rGBGrayToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 
            //copy Undo Image
            imgUndo = img.Copy();
            imgCopy = img.Copy();

            int[,] histogram = ImageClass.Histogram_All(img);

            Histograma form = new Histograma("All Channels and Gray Scale Histogram", histogram, 2);

            form.ShowDialog();

            Cursor = Cursors.Default; // normal cursor
        }

        private void manualToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();
            imgCopy = img.Copy();

            InputBox form = new InputBox("Binarization");

            form.label1.Text = "Threshold";
            form.label1.Visible = true;
            form.ValueTextBox.Visible = true;
            form.ValueTextBox.Text = "0";
            form.label2.Visible = false;
            form.ValueTextBox1.Visible = false;

            form.ShowDialog();

            int threshold = Convert.ToInt32(form.ValueTextBox.Text);

            if (threshold >= 0 && threshold <= 255)
            {
                    ImageClass.ConvertToBW(img, threshold);
            }

            else
            {
                    System.Windows.Forms.MessageBox.Show("Introduza um valor numérico 0 e 255", "Erro!");
            }

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        private void otsuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();
            imgCopy = img.Copy();

            ImageClass.ConvertToBW_Otsu(img);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        private void sobelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();
            imgCopy = img.Copy();

            ImageClass.Sobel(img, imgCopy);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        private void diferentiationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();
            imgCopy = img.Copy();

            ImageClass.Diferentiation(img, imgCopy);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }

        private void encontrarSinaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (img == null) // verify if the image is already opened
                return;
            Cursor = Cursors.WaitCursor; // clock cursor 

            //copy Undo Image
            imgUndo = img.Copy();
            imgCopy = img.Copy();

            List<string[]> limitSign;
            List<string[]> warningSign;
            List<string[]> prohibitionSign;
            int level = 1;

            img = ImageClass.Signs(img, imgCopy, out limitSign, out warningSign, out prohibitionSign, level);

            ImageViewer.Image = img.Bitmap;
            ImageViewer.Refresh(); // refresh image on the screen

            Cursor = Cursors.Default; // normal cursor 
        }
    }
}
