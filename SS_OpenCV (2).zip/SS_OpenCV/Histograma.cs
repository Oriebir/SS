﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ZedGraph;

namespace SS_OpenCV
{
    public partial class Histograma : Form
    {
        public Histograma(string _title, int[,] array, int type)
        {
            InitializeComponent();
            this.Text = _title;

            GraphPane myPane = zedGraphControl1.GraphPane;

            myPane.Title.Text = _title;
            myPane.XAxis.Title.Text = "Intensidade";
            myPane.YAxis.Title.Text = "Número de Pixeis";
            myPane.XAxis.Scale.MajorStep = 50;
            myPane.XAxis.Scale.MinorStep = 5;
            myPane.XAxis.Scale.Max = 255;
            myPane.XAxis.Scale.Min = 0;

            //Inicialização dos conjuntos de dados
            PointPairList DataSetGray = new PointPairList();
            PointPairList DataSetBlue = new PointPairList();
            PointPairList DataSetGreen = new PointPairList();
            PointPairList DataSetRed = new PointPairList();

            //Construção do conjunto de dados de escala de cinzentos
            for (int i = 0; i < 255; i++)
            {
                DataSetGray.Add(i, array[0, i]);
            }

            //Construção do conjunto de dados do canal azul
            for (int i = 0; i < 255; i++)
            {
                DataSetBlue.Add(i, array[1, i]);
            }

            //Construção do conjunto de dados do canal verde
            for (int i = 0; i < 255; i++)
            {
                DataSetGreen.Add(i, array[2, i]);
            }

            //Construção do conjunto de dados do canal vermelho
            for (int i = 0; i < 255; i++)
            {
                DataSetRed.Add(i, array[3, i]);
            }

            //Condições que definem o tipo de histograma a apresentar
            //Tipo 0: Histograma de Escala de Cinzentos
            //Tipo 1: Histograma conjunto dos três canais de cores
            //Tipo 2: Histograma que sobrepõe os outros dois histogramas

            if (type == 0)
            {          
                BarItem myBar = myPane.AddBar("Gray Scale", DataSetGray, Color.Black);
            }

            if (type == 1)
            {  
                LineItem myCurveRed = myPane.AddCurve("Red Channel", DataSetRed, Color.Red, SymbolType.None);
                LineItem myCurveGreen = myPane.AddCurve("Green Channel", DataSetGreen, Color.Green, SymbolType.None);
                LineItem myCurveBlue = myPane.AddCurve("Blue Channel", DataSetBlue, Color.Blue, SymbolType.None);
                //myPane.BarSettings.MinBarGap = 1;
                //myPane.BarSettings.MinClusterGap = 1;
            }

            if(type==2)
            {                
                LineItem myCurveRed = myPane.AddCurve("Red Channel", DataSetRed, Color.Red, SymbolType.None);
                LineItem myCurveGreen = myPane.AddCurve("Green Channel", DataSetGreen, Color.Green, SymbolType.None);
                LineItem myCurveBlue = myPane.AddCurve("Blue Channel", DataSetBlue, Color.Blue, SymbolType.None);
                LineItem myCurveGray = myPane.AddCurve("Gray Scale", DataSetGray, Color.Black, SymbolType.None);
            }


            zedGraphControl1.AxisChange();



            /*zedGraphControl1.Series[0].Color = Color.Gray;
            zedGraphControl1.ChartAreas[0].AxisX.Maximum = 255;
            zedGraphControl1.ChartAreas[0].AxisX.Minimum = 0;
            zedGraphControl1.ChartAreas[0].AxisX.Title = "Intensidade";
            zedGraphControl1.ChartAreas[0].AxisY.Title = "Numero Pixeis";
            zedGraphControl1.ResumeLayout();*/
        }        
    }
}
