﻿namespace SS_OpenCV
{
    partial class FilterEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OKbutton = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.ij00 = new System.Windows.Forms.TextBox();
            this.ij01 = new System.Windows.Forms.TextBox();
            this.ij02 = new System.Windows.Forms.TextBox();
            this.ij10 = new System.Windows.Forms.TextBox();
            this.ij12 = new System.Windows.Forms.TextBox();
            this.ij11 = new System.Windows.Forms.TextBox();
            this.ij20 = new System.Windows.Forms.TextBox();
            this.ij21 = new System.Windows.Forms.TextBox();
            this.ij22 = new System.Windows.Forms.TextBox();
            this.weight = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.filterType = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // OKbutton
            // 
            this.OKbutton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.OKbutton.Location = new System.Drawing.Point(46, 359);
            this.OKbutton.Name = "OKbutton";
            this.OKbutton.Size = new System.Drawing.Size(78, 20);
            this.OKbutton.TabIndex = 0;
            this.OKbutton.Text = "Ok";
            this.OKbutton.UseVisualStyleBackColor = true;
            this.OKbutton.Click += new System.EventHandler(this.OKbutton_Click);
            // 
            // button2
            // 
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(145, 359);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 19);
            this.button2.TabIndex = 1;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // ij00
            // 
            this.ij00.Location = new System.Drawing.Point(54, 65);
            this.ij00.Name = "ij00";
            this.ij00.Size = new System.Drawing.Size(24, 20);
            this.ij00.TabIndex = 2;
            // 
            // ij01
            // 
            this.ij01.Location = new System.Drawing.Point(84, 65);
            this.ij01.Name = "ij01";
            this.ij01.Size = new System.Drawing.Size(24, 20);
            this.ij01.TabIndex = 2;
            // 
            // ij02
            // 
            this.ij02.Location = new System.Drawing.Point(114, 65);
            this.ij02.Name = "ij02";
            this.ij02.Size = new System.Drawing.Size(24, 20);
            this.ij02.TabIndex = 2;
            // 
            // ij10
            // 
            this.ij10.Location = new System.Drawing.Point(54, 91);
            this.ij10.Name = "ij10";
            this.ij10.Size = new System.Drawing.Size(24, 20);
            this.ij10.TabIndex = 2;
            // 
            // ij12
            // 
            this.ij12.Location = new System.Drawing.Point(114, 91);
            this.ij12.Name = "ij12";
            this.ij12.Size = new System.Drawing.Size(24, 20);
            this.ij12.TabIndex = 2;
            // 
            // ij11
            // 
            this.ij11.Location = new System.Drawing.Point(84, 91);
            this.ij11.Name = "ij11";
            this.ij11.Size = new System.Drawing.Size(24, 20);
            this.ij11.TabIndex = 2;
            // 
            // ij20
            // 
            this.ij20.Location = new System.Drawing.Point(55, 117);
            this.ij20.Name = "ij20";
            this.ij20.Size = new System.Drawing.Size(24, 20);
            this.ij20.TabIndex = 2;
            // 
            // ij21
            // 
            this.ij21.Location = new System.Drawing.Point(84, 117);
            this.ij21.Name = "ij21";
            this.ij21.Size = new System.Drawing.Size(24, 20);
            this.ij21.TabIndex = 2;
            // 
            // ij22
            // 
            this.ij22.Location = new System.Drawing.Point(114, 117);
            this.ij22.Name = "ij22";
            this.ij22.Size = new System.Drawing.Size(24, 20);
            this.ij22.TabIndex = 2;
            // 
            // weight
            // 
            this.weight.Location = new System.Drawing.Point(84, 221);
            this.weight.Name = "weight";
            this.weight.Size = new System.Drawing.Size(54, 20);
            this.weight.TabIndex = 2;
            this.weight.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 224);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Weight";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.weight);
            this.groupBox1.Controls.Add(this.ij22);
            this.groupBox1.Controls.Add(this.ij21);
            this.groupBox1.Controls.Add(this.ij20);
            this.groupBox1.Controls.Add(this.ij12);
            this.groupBox1.Controls.Add(this.ij02);
            this.groupBox1.Controls.Add(this.ij11);
            this.groupBox1.Controls.Add(this.ij10);
            this.groupBox1.Controls.Add(this.ij01);
            this.groupBox1.Controls.Add(this.ij00);
            this.groupBox1.Location = new System.Drawing.Point(46, 74);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(179, 247);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Coeficients";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Filter Type";
            // 
            // filterType
            // 
            this.filterType.FormattingEnabled = true;
            this.filterType.Items.AddRange(new object[] {
            "Mean",
            "Border",
            "Gaussian",
            "Laplacian Hard",
            "Vertical Lines",
            "Custom"});
            this.filterType.Location = new System.Drawing.Point(104, 12);
            this.filterType.Name = "filterType";
            this.filterType.Size = new System.Drawing.Size(121, 21);
            this.filterType.TabIndex = 6;
            this.filterType.Tag = "";
            this.filterType.Text = "-Select Filter Type-";
            this.filterType.SelectedIndexChanged += new System.EventHandler(this.filterType_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Size";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "3x3",
            "5x5",
            "7x7"});
            this.comboBox2.Location = new System.Drawing.Point(104, 41);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 6;
            this.comboBox2.Text = "-Select Filter Size-";
            // 
            // FilterEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 447);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.filterType);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.OKbutton);
            this.Name = "FilterEditor";
            this.Text = "Filter Editor";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button OKbutton;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox2;
        public System.Windows.Forms.ComboBox filterType;
        public System.Windows.Forms.TextBox ij00;
        public System.Windows.Forms.TextBox ij01;
        public System.Windows.Forms.TextBox ij02;
        public System.Windows.Forms.TextBox ij10;
        public System.Windows.Forms.TextBox ij12;
        public System.Windows.Forms.TextBox ij11;
        public System.Windows.Forms.TextBox ij20;
        public System.Windows.Forms.TextBox ij21;
        public System.Windows.Forms.TextBox ij22;
        public System.Windows.Forms.TextBox weight;
    }
}