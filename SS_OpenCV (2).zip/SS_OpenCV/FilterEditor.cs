﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SS_OpenCV
{
    public partial class FilterEditor : Form
    {
        public FilterEditor()
        {
            InitializeComponent();
        }

        public FilterEditor(string _title)
        {
            InitializeComponent();

            this.Text = _title;

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void filterType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (filterType.SelectedIndex == 0)
            {
                ij00.Text = "1";
                ij01.Text = "1";
                ij02.Text = "1";
                ij10.Text = "1";
                ij11.Text = "1";
                ij12.Text = "1";
                ij20.Text = "1";
                ij21.Text = "1";
                ij22.Text = "1";
                weight.Text = "9";
            }

            if (filterType.SelectedIndex == 1)
            {
                ij00.Text = "-1";
                ij01.Text = "-1";
                ij02.Text = "-1";
                ij10.Text = "-1";
                ij11.Text = "9";
                ij12.Text = "-1";
                ij20.Text = "-1";
                ij21.Text = "-1";
                ij22.Text = "-1";
                weight.Text = "1";
            }

            if (filterType.SelectedIndex == 2)
            {
                ij00.Text = "1";
                ij01.Text = "2";
                ij02.Text = "1";
                ij10.Text = "2";
                ij11.Text = "4";
                ij12.Text = "2";
                ij20.Text = "1";
                ij21.Text = "2";
                ij22.Text = "1";
                weight.Text = "16";
            }

            if (filterType.SelectedIndex == 3)
            {
                ij00.Text = "1";
                ij01.Text = "-2";
                ij02.Text = "1";
                ij10.Text = "-2";
                ij11.Text = "4";
                ij12.Text = "-2";
                ij20.Text = "1";
                ij21.Text = "-2";
                ij22.Text = "1";
                weight.Text = "1";
            }

            if (filterType.SelectedIndex == 4)
            {
                ij00.Text = "0";
                ij01.Text = "0";
                ij02.Text = "0";
                ij10.Text = "-1";
                ij11.Text = "2";
                ij12.Text = "-1";
                ij20.Text = "0";
                ij21.Text = "0";
                ij22.Text = "0";
                weight.Text = "1";
            }

            if (filterType.SelectedIndex == 5)
            {
                ij00.Text = "0";
                ij01.Text = "0";
                ij02.Text = "0";
                ij10.Text = "0";
                ij11.Text = "1";
                ij12.Text = "0";
                ij20.Text = "0";
                ij21.Text = "0";
                ij22.Text = "0";
                weight.Text = "1";
            }
        }

        private void OKbutton_Click(object sender, EventArgs e)
        {
            return;
        }
    }
}
