﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ZedGraph;

namespace SS_OpenCV
{
    public partial class Histograma : Form
    {
        public Histograma(int[] array, string _title)
        {
            InitializeComponent();
            this.Text = _title;

            GraphPane myPane = zedGraphControl1.GraphPane;

            myPane.Title.Text = _title;
            myPane.XAxis.Title.Text = "Intensidade";
            myPane.YAxis.Title.Text = "Número de Pixeis";
        
            int size = array.Length;
            int[] DataPointCollection = new int[size];

            int np=0;

            PointPairList DataSet = new PointPairList();

            for (int i = 0; i < 255; i++)
            {
                for(int j = 0; j<array.Length; j++)
                {
                    if (array[j] == i)
                    {
                        np += 1;
                    }
                }

                DataSet.Add(i, np);
                np = 0;
            }

            LineItem myCurve = myPane.AddCurve("Histogram", DataSet, Color.Black);

            zedGraphControl1.AxisChange();

            /*zedGraphControl1.Series[0].Color = Color.Gray;
            zedGraphControl1.ChartAreas[0].AxisX.Maximum = 255;
            zedGraphControl1.ChartAreas[0].AxisX.Minimum = 0;
            zedGraphControl1.ChartAreas[0].AxisX.Title = "Intensidade";
            zedGraphControl1.ChartAreas[0].AxisY.Title = "Numero Pixeis";
            zedGraphControl1.ResumeLayout();*/
        }
    }
}
