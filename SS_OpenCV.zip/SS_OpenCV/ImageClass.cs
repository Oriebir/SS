﻿using System;
using System.Collections.Generic;
using System.Text;
using Emgu.CV.Structure;
using Emgu.CV;

namespace SS_OpenCV
{
    class ImageClass
    {

        /// <summary>
        /// Image Negative using EmguCV library
        /// Slower method
        /// </summary>
        /// <param name="img">Image</param>
        public static void Negative(Image<Bgr, byte> img)
        {
            /*int x, y;

            Bgr aux;
            for (y = 0; y < img.Height; y++)
            {
                for (x = 0; x < img.Width; x++)
                {
                    // acesso directo : mais lento 
                    aux = img[y, x];
                    img[y, x] = new Bgr(255 - aux.Blue, 255 - aux.Green, 255 - aux.Red);
                }
            }*/
            unsafe
            {
                MIplImage m = img.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer();
                byte blue, green, red;
                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels;
                int padding = m.widthStep - nChan * width;
                int x, y;

                for (y = 0; y < height; y++)
                {
                    for (x = 0; x < width; x++)
                    {
                        blue = dataPtr[0];
                        green = dataPtr[1];
                        red = dataPtr[2];

                        dataPtr[0] = (byte)(255 - blue);
                        dataPtr[1] = (byte)(255 - green);
                        dataPtr[2] = (byte)(255 - red);

                        dataPtr += nChan;
                    }

                    dataPtr += padding;
                }
            }
        }

        /// <summary>
        /// Convert to gray
        /// Direct access to memory - faster method
        /// </summary>
        /// <param name="img">image</param>
        public static void ConvertToGray(Image<Bgr, byte> img)
        {
            unsafe
            {
                // direct access to the image memory(sequencial)
                // direcion top left -> bottom right

                MIplImage m = img.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer(); // Pointer to the image
                byte blue, green, red, gray;

                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels; // number of channels - 3
                int padding = m.widthStep - m.nChannels * m.width; // alinhament bytes (padding)
                int x, y;

                if (nChan == 3) // image in RGB
                {
                    for (y = 0; y < height; y++)
                    {
                        for (x = 0; x < width; x++)
                        {
                            //retrive 3 colour components
                            blue = dataPtr[0];
                            green = dataPtr[1];
                            red = dataPtr[2];

                            // convert to gray
                            gray = (byte)Math.Round(((int)blue + green + red) / 3.0);

                            // store in the image
                            dataPtr[0] = gray;
                            dataPtr[1] = gray;
                            dataPtr[2] = gray;

                            // advance the pointer to the next pixel
                            dataPtr += nChan;
                        }

                        //at the end of the line advance the pointer by the aligment bytes (padding)
                        dataPtr += padding;
                    }
                }
            }
        }

        public static void RedChannel(Image<Bgr, byte> img)
        {
            unsafe
            {
                MIplImage m = img.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer();
                byte blue, green, red;
                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels;
                int padding = m.widthStep - nChan * width;
                int x, y;

                for (y = 0; y < height; y++)
                {
                    for (x = 0; x < width; x++)
                    {
                        blue = dataPtr[0];
                        green = dataPtr[1];
                        red = dataPtr[2];

                        dataPtr[0] = red;
                        dataPtr[1] = red;
                        dataPtr[2] = red;

                        dataPtr += nChan;
                    }

                    dataPtr += padding;
                }
            }
        }

        public static void GreenChannel(Image<Bgr, byte> img)
        {
            unsafe
            {
                MIplImage m = img.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer();
                byte blue, green, red;
                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels;
                int padding = m.widthStep - nChan * width;
                int x, y;

                for (y = 0; y < height; y++)
                {
                    for (x = 0; x < width; x++)
                    {
                        blue = dataPtr[0];
                        green = dataPtr[1];
                        red = dataPtr[2];

                        dataPtr[0] = green;
                        dataPtr[1] = green;
                        dataPtr[2] = green;

                        dataPtr += nChan;
                    }

                    dataPtr += padding;
                }
            }
        }

        public static void BlueChannel(Image<Bgr, byte> img)
        {
            unsafe
            {
                MIplImage m = img.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer();
                byte blue, green, red;
                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels;
                int padding = m.widthStep - nChan * width;
                int x, y;

                for (y = 0; y < height; y++)
                {
                    for (x = 0; x < width; x++)
                    {
                        blue = dataPtr[0];
                        green = dataPtr[1];
                        red = dataPtr[2];

                        dataPtr[0] = blue;
                        dataPtr[1] = blue;
                        dataPtr[2] = blue;

                        dataPtr += nChan;
                    }

                    dataPtr += padding;
                }
            }
        }

        public static void BrightContrast(Image<Bgr, byte> img, int bright, double contrast)
        {
            unsafe
            {
                MIplImage m = img.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer();
                byte blue, green, red;
                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels;
                int padding = m.widthStep - nChan * width;
                int x, y;
                int b = bright;
                double c = contrast;

                for (y = 0; y < height; y++)
                {
                    for (x = 0; x < width; x++)
                    {
                        //retrive 3 colour components
                        blue = dataPtr[0];
                        green = dataPtr[1];
                        red = dataPtr[2];

                        //Ajuste de Brilho e Contraste
                        int adjustBlue = (int)Math.Round(c * blue + b);
                        int adjustGreen = (int)Math.Round(c * green + b);
                        int adjustRed = (int)Math.Round(c * red + b);

                        if (adjustBlue < 255 && adjustBlue > 0)
                        {
                            dataPtr[0] = (byte)(adjustBlue);
                        }
                        //Saturação a 0
                        else if (adjustBlue <= 0)
                        {
                            dataPtr[0] = 0;
                        }

                        //Saturação a 255
                        else if (adjustBlue >= 255)
                        {
                            dataPtr[0] = 255;
                        }

                        if (adjustGreen < 255 && adjustGreen > 0)
                        {
                            dataPtr[1] = (byte)adjustGreen;
                        }
                        //Saturação
                        else if (adjustGreen <= 0)
                        {
                            dataPtr[1] = 0;
                        }

                        //Saturação a 255
                        else if (adjustGreen >= 255)
                        {
                            dataPtr[1] = 255;
                        }

                        if (adjustRed < 255 && adjustRed > 0)
                        {
                            dataPtr[2] = (byte)adjustRed;
                        }
                        //Saturação
                        else if (adjustRed <= 0)
                        {
                            dataPtr[2] = 0;
                        }

                        //Saturação a 255
                        else if (adjustRed >= 255)
                        {
                            dataPtr[2] = 255;
                        }

                        dataPtr += nChan;
                    }

                    dataPtr += padding;

                }

            }
        }

        public static void Translation(Image<Bgr, byte> img, Image<Bgr, byte> imgCopy, int dx, int dy)
        {

            unsafe
            {
                MIplImage m = img.MIplImage;
                MIplImage mcopy = imgCopy.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer();
                byte* copyPtr = (byte*)mcopy.imageData.ToPointer();
                byte blue, green, red;
                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels;
                int x, y, xo, yo;

                for (y = 0; y < height; y++)
                {
                    for (x = 0; x < width; x++)
                    {
                        xo = x - dx;
                        yo = y - dy;

                        if (xo >= 0 && yo >= 0 && yo < height && xo < width)
                        {
                            blue = (byte)(copyPtr + yo * mcopy.widthStep + xo * nChan)[0];
                            green = (byte)(copyPtr + yo * mcopy.widthStep + xo * nChan)[1];
                            red = (byte)(copyPtr + yo * mcopy.widthStep + xo * nChan)[2];

                            (dataPtr + y * m.widthStep + x * nChan)[0] = blue;
                            (dataPtr + y * m.widthStep + x * nChan)[1] = green;
                            (dataPtr + y * m.widthStep + x * nChan)[2] = red;
                        }

                        else
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[0] = 0;
                            (dataPtr + y * m.widthStep + x * nChan)[1] = 0;
                            (dataPtr + y * m.widthStep + x * nChan)[2] = 0;
                        }

                    }
                }


            }


        }

        public static void Rotation(Image<Bgr, byte> img, Image<Bgr, byte> imgCopy, float angle)
        {

            unsafe
            {
                MIplImage m = img.MIplImage;
                MIplImage mcopy = imgCopy.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer();
                byte* copyPtr = (byte*)mcopy.imageData.ToPointer();
                byte blue, green, red;
                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels;
                int x, y, xo, yo;

                for (y = 0; y < height; y++)
                {
                    for (x = 0; x < width; x++)
                    {
                        xo = (int)Math.Round((x - (width / 2.0)) * Math.Cos(angle) - ((height / 2.0) - y) * Math.Sin(angle) + (width / 2.0));
                        yo = (int)Math.Round((height / 2.0) - (x - (width / 2.0)) * Math.Sin(angle) - ((height / 2.0) - y) * Math.Cos(angle));

                        if (xo >= 0 && yo >= 0 && yo < height && xo < width)
                        {
                            blue = (byte)(copyPtr + yo * mcopy.widthStep + xo * nChan)[0];
                            green = (byte)(copyPtr + yo * mcopy.widthStep + xo * nChan)[1];
                            red = (byte)(copyPtr + yo * mcopy.widthStep + xo * nChan)[2];

                            (dataPtr + y * m.widthStep + x * nChan)[0] = blue;
                            (dataPtr + y * m.widthStep + x * nChan)[1] = green;
                            (dataPtr + y * m.widthStep + x * nChan)[2] = red;
                        }

                        else
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[0] = 0;
                            (dataPtr + y * m.widthStep + x * nChan)[1] = 0;
                            (dataPtr + y * m.widthStep + x * nChan)[2] = 0;
                        }

                    }
                }


            }


        }

        public static void Scale(Image<Bgr, byte> img, Image<Bgr, byte> imgCopy, float scaleFactor)
        {
            unsafe
            {
                MIplImage m = img.MIplImage;
                MIplImage mcopy = imgCopy.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer();
                byte* copyPtr = (byte*)mcopy.imageData.ToPointer();
                byte blue, green, red;
                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels;
                int x, y, xo, yo;

                for (y = 0; y < height; y++)
                {
                    for (x = 0; x < width; x++)
                    {
                        xo = (int)Math.Round(x / scaleFactor);
                        yo = (int)Math.Round(y / scaleFactor);

                        if (xo >= 0 && yo >= 0 && yo < height && xo < width)
                        {
                            blue = (byte)(copyPtr + yo * mcopy.widthStep + xo * nChan)[0];
                            green = (byte)(copyPtr + yo * mcopy.widthStep + xo * nChan)[1];
                            red = (byte)(copyPtr + yo * mcopy.widthStep + xo * nChan)[2];

                            (dataPtr + y * m.widthStep + x * nChan)[0] = blue;
                            (dataPtr + y * m.widthStep + x * nChan)[1] = green;
                            (dataPtr + y * m.widthStep + x * nChan)[2] = red;
                        }

                        else
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[0] = 0;
                            (dataPtr + y * m.widthStep + x * nChan)[1] = 0;
                            (dataPtr + y * m.widthStep + x * nChan)[2] = 0;
                        }

                    }
                }


            }
        }

        public static void Scale_point_xy(Image<Bgr, byte> img, Image<Bgr, byte> imgCopy, float scaleFactor, int centerX, int centerY)
        {
            unsafe
            {
                MIplImage m = img.MIplImage;
                MIplImage mcopy = imgCopy.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer();
                byte* copyPtr = (byte*)mcopy.imageData.ToPointer();
                byte blue, green, red;
                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels;
                int x, y, xo, yo;

                for (y = centerY; y < height; y++)
                {
                    for (x = centerX; x < width; x++)
                    {
                        xo = (int)Math.Round(x / scaleFactor);
                        yo = (int)Math.Round(y / scaleFactor);

                        if (xo >= 0 && yo >= 0 && yo < height && xo < width)
                        {
                            blue = (byte)(copyPtr + yo * mcopy.widthStep + xo * nChan)[0];
                            green = (byte)(copyPtr + yo * mcopy.widthStep + xo * nChan)[1];
                            red = (byte)(copyPtr + yo * mcopy.widthStep + xo * nChan)[2];

                            (dataPtr + y * m.widthStep + x * nChan)[0] = blue;
                            (dataPtr + y * m.widthStep + x * nChan)[1] = green;
                            (dataPtr + y * m.widthStep + x * nChan)[2] = red;
                        }

                        else
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[0] = 0;
                            (dataPtr + y * m.widthStep + x * nChan)[1] = 0;
                            (dataPtr + y * m.widthStep + x * nChan)[2] = 0;
                        }

                    }
                }


            }
        }

        public static void Mean(Image<Bgr, byte> img, Image<Bgr, byte> imgCopy)
        {
            unsafe
            {
                MIplImage m = img.MIplImage;
                MIplImage mcopy = imgCopy.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer();
                byte* copyPtr = (byte*)mcopy.imageData.ToPointer();
                int blue, green, red;
                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels;
                int x, y;

                for (y = 1; y < (height - 1); y++)
                {
                    for (x = 1; x < (width - 1); x++)
                    {
                        //cálculo da média na compenente azul para um filtro 3x3
                        blue = (int)Math.Round((double)((copyPtr + (y - 1) * mcopy.widthStep + (x - 1) * nChan)[0] +
                            (copyPtr + (y - 1) * mcopy.widthStep + x * nChan)[0] + (copyPtr + (y - 1) * mcopy.widthStep + (x + 1) * nChan)[0] +
                            (copyPtr + (y) * mcopy.widthStep + (x - 1) * nChan)[0] +
                            (copyPtr + (y) * mcopy.widthStep + x * nChan)[0] + (copyPtr + (y) * mcopy.widthStep + (x + 1) * nChan)[0] +
                            (copyPtr + (y + 1) * mcopy.widthStep + (x - 1) * nChan)[0] +
                            (copyPtr + (y + 1) * mcopy.widthStep + x * nChan)[0] + (copyPtr + (y + 1) * mcopy.widthStep + (x + 1) * nChan)[0]) / 9);

                        //cálculo da média na compenente verde para um filtro 3x3
                        green = (int)Math.Round((double)((copyPtr + (y - 1) * mcopy.widthStep + (x - 1) * nChan)[1] +
                            (copyPtr + (y - 1) * mcopy.widthStep + x * nChan)[1] + (copyPtr + (y - 1) * mcopy.widthStep + (x + 1) * nChan)[1] +
                            (copyPtr + (y) * mcopy.widthStep + (x - 1) * nChan)[1] +
                            (copyPtr + (y) * mcopy.widthStep + x * nChan)[1] + (copyPtr + (y) * mcopy.widthStep + (x + 1) * nChan)[1] +
                            (copyPtr + (y + 1) * mcopy.widthStep + (x - 1) * nChan)[1] +
                            (copyPtr + (y + 1) * mcopy.widthStep + x * nChan)[1] + (copyPtr + (y + 1) * mcopy.widthStep + (x + 1) * nChan)[1]) / 9);

                        //cálculo da média na compenente vermelha para um filtro 3x3
                        red = (int)Math.Round((double)((copyPtr + (y - 1) * mcopy.widthStep + (x - 1) * nChan)[2] +
                            (copyPtr + (y - 1) * mcopy.widthStep + x * nChan)[2] + (copyPtr + (y - 1) * mcopy.widthStep + (x + 1) * nChan)[2] +
                            (copyPtr + (y) * mcopy.widthStep + (x - 1) * nChan)[2] +
                            (copyPtr + (y) * mcopy.widthStep + x * nChan)[2] + (copyPtr + (y) * mcopy.widthStep + (x + 1) * nChan)[2] +
                            (copyPtr + (y + 1) * mcopy.widthStep + (x - 1) * nChan)[2] +
                            (copyPtr + (y + 1) * mcopy.widthStep + x * nChan)[2] + (copyPtr + (y + 1) * mcopy.widthStep + (x + 1) * nChan)[2]) / 9);

                        (dataPtr + y * m.widthStep + x * nChan)[0] = (byte)blue;
                        (dataPtr + y * m.widthStep + x * nChan)[1] = (byte)green;
                        (dataPtr + y * m.widthStep + x * nChan)[2] = (byte)red;
                    }
                }

                //Margem esquerda sem cantos
                for (y = 1; y < (height - 1); y++)
                {
                    //cálculo da média na compenente azul para um filtro 3x3
                    blue = (int)Math.Round((double)(2 * (copyPtr + (y - 1) * mcopy.widthStep + 0 * nChan)[0] + (copyPtr + (y - 1) * mcopy.widthStep + (1) * nChan)[0] +
                        2 * (copyPtr + (y) * mcopy.widthStep + 0 * nChan)[0] + (copyPtr + (y) * mcopy.widthStep + (1) * nChan)[0] +
                        2 * (copyPtr + (y + 1) * mcopy.widthStep + 0 * nChan)[0] + (copyPtr + (y + 1) * mcopy.widthStep + (1) * nChan)[0]) / 9);

                    //cálculo da média na compenente verde para um filtro 3x3
                    green = (int)Math.Round((double)(2 * (copyPtr + (y - 1) * mcopy.widthStep + 0 * nChan)[1] + (copyPtr + (y - 1) * mcopy.widthStep + (1) * nChan)[1] +
                        2 * (copyPtr + (y) * mcopy.widthStep + 0 * nChan)[1] + (copyPtr + (y) * mcopy.widthStep + (1) * nChan)[1] +
                        2 * (copyPtr + (y + 1) * mcopy.widthStep + 0 * nChan)[1] + (copyPtr + (y + 1) * mcopy.widthStep + (1) * nChan)[1]) / 9);

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    red = (int)Math.Round((double)(2 * (copyPtr + (y - 1) * mcopy.widthStep + 0 * nChan)[2] + (copyPtr + (y - 1) * mcopy.widthStep + (1) * nChan)[2] +
                        2 * (copyPtr + (y) * mcopy.widthStep + 0 * nChan)[2] + (copyPtr + (y) * mcopy.widthStep + (1) * nChan)[2] +
                        2 * (copyPtr + (y + 1) * mcopy.widthStep + 0 * nChan)[2] + (copyPtr + (y + 1) * mcopy.widthStep + (1) * nChan)[2]) / 9);

                    (dataPtr + y * m.widthStep + 0 * nChan)[0] = (byte)blue;
                    (dataPtr + y * m.widthStep + 0 * nChan)[1] = (byte)green;
                    (dataPtr + y * m.widthStep + 0 * nChan)[2] = (byte)red;
                }

                //Margem direita sem cantos
                for (y = 1; y < (height - 1); y++)
                {
                    //cálculo da média na compenente azul para um filtro 3x3
                    blue = (int)Math.Round((double)(2 * (copyPtr + (y - 1) * mcopy.widthStep + (width - 1) * nChan)[0] + (copyPtr + (y - 1) * mcopy.widthStep + (width - 2) * nChan)[0] +
                        2 * (copyPtr + (y) * mcopy.widthStep + (width - 1) * nChan)[0] + (copyPtr + (y) * mcopy.widthStep + (width - 2) * nChan)[0] +
                        2 * (copyPtr + (y + 1) * mcopy.widthStep + (width - 1) * nChan)[0] + (copyPtr + (y + 1) * mcopy.widthStep + (width - 2) * nChan)[0]) / 9);

                    //cálculo da média na compenente verde para um filtro 3x3
                    green = (int)Math.Round((double)(2 * (copyPtr + (y - 1) * mcopy.widthStep + (width - 1) * nChan)[1] + (copyPtr + (y - 1) * mcopy.widthStep + (width - 2) * nChan)[1] +
                        2 * (copyPtr + (y) * mcopy.widthStep + (width - 1) * nChan)[1] + (copyPtr + (y) * mcopy.widthStep + (width - 2) * nChan)[1] +
                        2 * (copyPtr + (y + 1) * mcopy.widthStep + (width - 1) * nChan)[1] + (copyPtr + (y + 1) * mcopy.widthStep + (width - 2) * nChan)[1]) / 9);

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    red = (int)Math.Round((double)(2 * (copyPtr + (y - 1) * mcopy.widthStep + (width - 1) * nChan)[2] + (copyPtr + (y - 1) * mcopy.widthStep + (width - 2) * nChan)[2] +
                        2 * (copyPtr + (y) * mcopy.widthStep + (width - 1) * nChan)[2] + (copyPtr + (y) * mcopy.widthStep + (width - 2) * nChan)[2] +
                        2 * (copyPtr + (y + 1) * mcopy.widthStep + (width - 1) * nChan)[2] + (copyPtr + (y + 1) * mcopy.widthStep + (width - 2) * nChan)[2]) / 9);

                    (dataPtr + y * m.widthStep + (width - 1) * nChan)[0] = (byte)blue;
                    (dataPtr + y * m.widthStep + (width - 1) * nChan)[1] = (byte)green;
                    (dataPtr + y * m.widthStep + (width - 1) * nChan)[2] = (byte)red;
                }

                //Margem superior sem cantos
                for (x = 1; x < (width - 1); x++)
                {
                    //cálculo da média na compenente azul para um filtro 3x3
                    blue = (int)Math.Round((double)(2 * (copyPtr + (0) * mcopy.widthStep + (x - 1) * nChan)[0] + (copyPtr + (1) * mcopy.widthStep + (x - 1) * nChan)[0] +
                        2 * (copyPtr + (0) * mcopy.widthStep + x * nChan)[0] + (copyPtr + (1) * mcopy.widthStep + (x) * nChan)[0] +
                        2 * (copyPtr + (0) * mcopy.widthStep + (x + 1) * nChan)[0] + (copyPtr + (1) * mcopy.widthStep + (x + 1) * nChan)[0]) / 9);

                    //cálculo da média na compenente verde para um filtro 3x3
                    green = (int)Math.Round((double)(2 * (copyPtr + (0) * mcopy.widthStep + (x - 1) * nChan)[1] + (copyPtr + (1) * mcopy.widthStep + (x - 1) * nChan)[1] +
                        2 * (copyPtr + (0) * mcopy.widthStep + x * nChan)[1] + (copyPtr + (1) * mcopy.widthStep + (x) * nChan)[1] +
                        2 * (copyPtr + (0) * mcopy.widthStep + (x + 1) * nChan)[1] + (copyPtr + (1) * mcopy.widthStep + (x + 1) * nChan)[1]) / 9);

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    red = (int)Math.Round((double)(2 * (copyPtr + (0) * mcopy.widthStep + (x - 1) * nChan)[2] + (copyPtr + (1) * mcopy.widthStep + (x - 1) * nChan)[2] +
                        2 * (copyPtr + (0) * mcopy.widthStep + x * nChan)[2] + (copyPtr + (1) * mcopy.widthStep + (x) * nChan)[2] +
                        2 * (copyPtr + (0) * mcopy.widthStep + (x + 1) * nChan)[2] + (copyPtr + (1) * mcopy.widthStep + (x + 1) * nChan)[2]) / 9);

                    (dataPtr + 0 * m.widthStep + x * nChan)[0] = (byte)blue;
                    (dataPtr + 0 * m.widthStep + x * nChan)[1] = (byte)green;
                    (dataPtr + 0 * m.widthStep + x * nChan)[2] = (byte)red;
                }

                //Margem inferior sem cantos
                for (x = 1; x < (width - 1); x++)
                {
                    //cálculo da média na compenente azul para um filtro 3x3
                    blue = (int)Math.Round((double)(2 * (copyPtr + (height - 1) * mcopy.widthStep + (x - 1) * nChan)[0] + (copyPtr + (height - 2) * mcopy.widthStep + (x - 1) * nChan)[0] +
                        2 * (copyPtr + (height - 1) * mcopy.widthStep + x * nChan)[0] + (copyPtr + (height - 2) * mcopy.widthStep + (x) * nChan)[0] +
                        2 * (copyPtr + (height - 1) * mcopy.widthStep + (x + 1) * nChan)[0] + (copyPtr + (height - 2) * mcopy.widthStep + (x + 1) * nChan)[0]) / 9);

                    //cálculo da média na compenente verde para um filtro 3x3
                    green = (int)Math.Round((double)(2 * (copyPtr + (height - 1) * mcopy.widthStep + (x - 1) * nChan)[1] + (copyPtr + (height - 2) * mcopy.widthStep + (x - 1) * nChan)[1] +
                        2 * (copyPtr + (height - 1) * mcopy.widthStep + x * nChan)[1] + (copyPtr + (height - 2) * mcopy.widthStep + (x) * nChan)[1] +
                        2 * (copyPtr + (height - 1) * mcopy.widthStep + (x + 1) * nChan)[1] + (copyPtr + (height - 2) * mcopy.widthStep + (x + 1) * nChan)[1]) / 9);

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    red = (int)Math.Round((double)(2 * (copyPtr + (height - 1) * mcopy.widthStep + (x - 1) * nChan)[2] + (copyPtr + (height - 2) * mcopy.widthStep + (x - 1) * nChan)[2] +
                        2 * (copyPtr + (height - 1) * mcopy.widthStep + x * nChan)[2] + (copyPtr + (height - 2) * mcopy.widthStep + (x) * nChan)[2] +
                        2 * (copyPtr + (height - 1) * mcopy.widthStep + (x + 1) * nChan)[2] + (copyPtr + (height - 2) * mcopy.widthStep + (x + 1) * nChan)[2]) / 9);

                    (dataPtr + (height - 1) * m.widthStep + x * nChan)[0] = (byte)blue;
                    (dataPtr + (height - 1) * m.widthStep + x * nChan)[1] = (byte)green;
                    (dataPtr + (height - 1) * m.widthStep + x * nChan)[2] = (byte)red;
                }

                //Canto Superior Esquerdo

                //cálculo da média na compenente azul para um filtro 3x3
                blue = (int)Math.Round((double)(4 * (copyPtr + (0) * mcopy.widthStep + (0) * nChan)[0] +
                    2 * (copyPtr + (0) * mcopy.widthStep + 1 * nChan)[0] +
                    2 * (copyPtr + (1) * mcopy.widthStep + (0) * nChan)[0] + (copyPtr + (1) * mcopy.widthStep + (1) * nChan)[0]) / 9);

                //cálculo da média na compenente verde para um filtro 3x3
                green = (int)Math.Round((double)(4 * (copyPtr + (0) * mcopy.widthStep + (0) * nChan)[1] +
                    2 * (copyPtr + (0) * mcopy.widthStep + 1 * nChan)[1] +
                    2 * (copyPtr + (1) * mcopy.widthStep + (0) * nChan)[1] + (copyPtr + (1) * mcopy.widthStep + (1) * nChan)[1]) / 9);

                //cálculo da média na compenente vermelha para um filtro 3x3
                red = (int)Math.Round((double)(4 * (copyPtr + (0) * mcopy.widthStep + (0) * nChan)[2] +
                    2 * (copyPtr + (0) * mcopy.widthStep + 1 * nChan)[2] +
                    2 * (copyPtr + (1) * mcopy.widthStep + (0) * nChan)[2] + (copyPtr + (1) * mcopy.widthStep + (1) * nChan)[2]) / 9);

                (dataPtr + 0 * m.widthStep + 0 * nChan)[0] = (byte)blue;
                (dataPtr + 0 * m.widthStep + 0 * nChan)[1] = (byte)green;
                (dataPtr + 0 * m.widthStep + 0 * nChan)[2] = (byte)red;

                //Canto Superior Direito

                //cálculo da média na compenente azul para um filtro 3x3
                blue = (int)Math.Round((double)(4 * (copyPtr + (0) * mcopy.widthStep + (width - 1) * nChan)[0] +
                    2 * (copyPtr + (0) * mcopy.widthStep + (width - 2) * nChan)[0] +
                    2 * (copyPtr + (1) * mcopy.widthStep + (width - 1) * nChan)[0] + (copyPtr + (1) * mcopy.widthStep + (width - 2) * nChan)[0]) / 9);

                //cálculo da média na compenente verde para um filtro 3x3
                green = (int)Math.Round((double)(4 * (copyPtr + (0) * mcopy.widthStep + (width - 1) * nChan)[1] +
                    2 * (copyPtr + (0) * mcopy.widthStep + (width - 2) * nChan)[1] +
                    2 * (copyPtr + (1) * mcopy.widthStep + (width - 1) * nChan)[1] + (copyPtr + (1) * mcopy.widthStep + (width - 2) * nChan)[1]) / 9);

                //cálculo da média na compenente vermelha para um filtro 3x3
                red = (int)Math.Round((double)(4 * (copyPtr + (0) * mcopy.widthStep + (width - 1) * nChan)[2] +
                    2 * (copyPtr + (0) * mcopy.widthStep + (width - 2) * nChan)[2] +
                    2 * (copyPtr + (1) * mcopy.widthStep + (width - 1) * nChan)[2] + (copyPtr + (1) * mcopy.widthStep + (width - 2) * nChan)[2]) / 9);

                (dataPtr + 0 * m.widthStep + width * nChan)[0] = (byte)blue;
                (dataPtr + 0 * m.widthStep + width * nChan)[1] = (byte)green;
                (dataPtr + 0 * m.widthStep + width * nChan)[2] = (byte)red;

                //Canto Inferior Esquerdo

                //cálculo da média na compenente azul para um filtro 3x3
                blue = (int)Math.Round((double)(4 * (copyPtr + (height - 1) * mcopy.widthStep + (0) * nChan)[0] +
                    2 * (copyPtr + (height - 1) * mcopy.widthStep + (1) * nChan)[0] +
                    2 * (copyPtr + (height - 2) * mcopy.widthStep + (0) * nChan)[0] + (copyPtr + (height - 2) * mcopy.widthStep + (1) * nChan)[0]) / 9);

                //cálculo da média na compenente verde para um filtro 3x3
                green = (int)Math.Round((double)(4 * (copyPtr + (height - 1) * mcopy.widthStep + (0) * nChan)[1] +
                    2 * (copyPtr + (height - 1) * mcopy.widthStep + (1) * nChan)[1] +
                    2 * (copyPtr + (height - 2) * mcopy.widthStep + (0) * nChan)[1] + (copyPtr + (height - 2) * mcopy.widthStep + (1) * nChan)[1]) / 9);

                //cálculo da média na compenente vermelha para um filtro 3x3
                red = (int)Math.Round((double)(4 * (copyPtr + (height - 1) * mcopy.widthStep + (0) * nChan)[2] +
                    2 * (copyPtr + (height - 1) * mcopy.widthStep + (1) * nChan)[2] +
                    2 * (copyPtr + (height - 2) * mcopy.widthStep + (0) * nChan)[2] + (copyPtr + (height - 2) * mcopy.widthStep + (1) * nChan)[2]) / 9);

                (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[0] = (byte)blue;
                (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[1] = (byte)green;
                (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[2] = (byte)red;

                //Canto Inferior Direito

                //cálculo da média na compenente azul para um filtro 3x3
                blue = (int)Math.Round((double)(4 * (copyPtr + (height - 1) * mcopy.widthStep + (width - 1) * nChan)[0] +
                    2 * (copyPtr + (height - 1) * mcopy.widthStep + (width - 2) * nChan)[0] +
                    2 * (copyPtr + (height - 2) * mcopy.widthStep + (width - 1) * nChan)[0] + (copyPtr + (height - 2) * mcopy.widthStep + (width - 2) * nChan)[0]) / 9);

                //cálculo da média na compenente verde para um filtro 3x3
                green = (int)Math.Round((double)(4 * (copyPtr + (height - 1) * mcopy.widthStep + (width - 1) * nChan)[1] +
                    2 * (copyPtr + (height - 1) * mcopy.widthStep + (width - 2) * nChan)[1] +
                    2 * (copyPtr + (height - 2) * mcopy.widthStep + (width - 1) * nChan)[1] + (copyPtr + (height - 2) * mcopy.widthStep + (width - 2) * nChan)[1]) / 9);

                //cálculo da média na compenente vermelha para um filtro 3x3
                red = (int)Math.Round((double)(4 * (copyPtr + (height - 1) * mcopy.widthStep + (width - 1) * nChan)[2] +
                    2 * (copyPtr + (height - 1) * mcopy.widthStep + (width - 2) * nChan)[2] +
                    2 * (copyPtr + (height - 2) * mcopy.widthStep + (width - 1) * nChan)[2] + (copyPtr + (height - 2) * mcopy.widthStep + (width - 2) * nChan)[2]) / 9);

                (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[0] = (byte)blue;
                (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[1] = (byte)green;
                (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[2] = (byte)red;
            }


        }

        public static void NonUniform(Image<Bgr, byte> img, Image<Bgr, byte> imgCopy, float[,] matrix, float matrixWeight)
        {
            unsafe
            {
                MIplImage m = img.MIplImage;
                MIplImage mcopy = imgCopy.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer();
                byte* copyPtr = (byte*)mcopy.imageData.ToPointer();
                int blue, green, red;
                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels;
                int x, y;

                for (y = 1; y < (height - 1); y++)
                {
                    for (x = 1; x < (width - 1); x++)
                    {
                        //cálculo da média na compenente azul para um filtro 3x3
                        blue = (int)Math.Round((double)((copyPtr + (y - 1) * mcopy.widthStep + (x - 1) * nChan)[0] * matrix[0, 0] +
                            (copyPtr + (y - 1) * mcopy.widthStep + x * nChan)[0] * matrix[0, 1] + (copyPtr + (y - 1) * mcopy.widthStep + (x + 1) * nChan)[0] * matrix[0, 2] +
                            (copyPtr + (y) * mcopy.widthStep + (x - 1) * nChan)[0] * matrix[1, 0] +
                            (copyPtr + (y) * mcopy.widthStep + x * nChan)[0] * matrix[1, 1] + (copyPtr + (y) * mcopy.widthStep + (x + 1) * nChan)[0] * matrix[1, 2] +
                            (copyPtr + (y + 1) * mcopy.widthStep + (x - 1) * nChan)[0] * matrix[2, 0] +
                            (copyPtr + (y + 1) * mcopy.widthStep + x * nChan)[0] * matrix[2, 1] + (copyPtr + (y + 1) * mcopy.widthStep + (x + 1) * nChan)[0] * matrix[2, 2]) / matrixWeight);

                        //cálculo da média na compenente verde para um filtro 3x3
                        green = (int)Math.Round((double)((copyPtr + (y - 1) * mcopy.widthStep + (x - 1) * nChan)[1] * matrix[0, 0] +
                            (copyPtr + (y - 1) * mcopy.widthStep + x * nChan)[1] * matrix[0, 1] + (copyPtr + (y - 1) * mcopy.widthStep + (x + 1) * nChan)[1] * matrix[0, 2] +
                            (copyPtr + (y) * mcopy.widthStep + (x - 1) * nChan)[1] * matrix[1, 0] +
                            (copyPtr + (y) * mcopy.widthStep + x * nChan)[1] * matrix[1, 1] + (copyPtr + (y) * mcopy.widthStep + (x + 1) * nChan)[1] * matrix[1, 2] +
                            (copyPtr + (y + 1) * mcopy.widthStep + (x - 1) * nChan)[1] * matrix[2, 0] +
                            (copyPtr + (y + 1) * mcopy.widthStep + x * nChan)[1] * matrix[2, 1] + (copyPtr + (y + 1) * mcopy.widthStep + (x + 1) * nChan)[1] * matrix[2, 2]) / matrixWeight);

                        //cálculo da média na compenente vermelha para um filtro 3x3
                        red = (int)Math.Round((double)((copyPtr + (y - 1) * mcopy.widthStep + (x - 1) * nChan)[2] * matrix[0, 0] +
                            (copyPtr + (y - 1) * mcopy.widthStep + x * nChan)[2] * matrix[0, 1] + (copyPtr + (y - 1) * mcopy.widthStep + (x + 1) * nChan)[2] * matrix[0, 2] +
                            (copyPtr + (y) * mcopy.widthStep + (x - 1) * nChan)[2] * matrix[1, 0] +
                            (copyPtr + (y) * mcopy.widthStep + x * nChan)[2] * matrix[1, 1] + (copyPtr + (y) * mcopy.widthStep + (x + 1) * nChan)[2] * matrix[1, 2] +
                            (copyPtr + (y + 1) * mcopy.widthStep + (x - 1) * nChan)[2] * matrix[2, 0] +
                            (copyPtr + (y + 1) * mcopy.widthStep + x * nChan)[2] * matrix[2, 1] + (copyPtr + (y + 1) * mcopy.widthStep + (x + 1) * nChan)[2] * matrix[2, 2]) / matrixWeight);

                        if (blue > 0 && blue < 255)

                        {
                            (dataPtr + y * m.widthStep + x * nChan)[0] = (byte)blue;
                        }

                        else if (blue <= 0)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[0] = 0;
                        }

                        else if (blue >= 255)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[0] = 255;
                        }

                        if (green > 0 && green < 255)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[1] = (byte)green;
                        }

                        else if (green <= 0)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[1] = 0;
                        }

                        else if (green >= 255)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[1] = 255;
                        }

                        if (red > 0 && red < 255)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[2] = (byte)red;
                        }

                        else if (red <= 0)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[2] = 0;
                        }

                        else if (red >= 255)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[2] = 255;
                        }
                    }
                }

                //Margem esquerda sem cantos
                for (y = 1; y < (height - 1); y++)
                {
                    //cálculo da média na compenente azul para um filtro 3x3
                    blue = (int)Math.Round((double)((matrix[0, 0] + matrix[0, 1]) * (copyPtr + (y - 1) * mcopy.widthStep + 0 * nChan)[0] + matrix[0, 2] * (copyPtr + (y - 1) * mcopy.widthStep + (1) * nChan)[0] +
                        (matrix[1, 0] + matrix[1, 1]) * (copyPtr + (y) * mcopy.widthStep + 0 * nChan)[0] + matrix[1, 2] * (copyPtr + (y) * mcopy.widthStep + (1) * nChan)[0] +
                        (matrix[2, 0] + matrix[2, 1]) * (copyPtr + (y + 1) * mcopy.widthStep + 0 * nChan)[0] + matrix[2, 2] * (copyPtr + (y + 1) * mcopy.widthStep + (1) * nChan)[0]) / matrixWeight);

                    //cálculo da média na compenente verde para um filtro 3x3
                    green = (int)Math.Round((double)((matrix[0, 0] + matrix[0, 1]) * (copyPtr + (y - 1) * mcopy.widthStep + 0 * nChan)[1] + matrix[0, 2] * (copyPtr + (y - 1) * mcopy.widthStep + (1) * nChan)[1] +
                        (matrix[1, 0] + matrix[1, 1]) * (copyPtr + (y) * mcopy.widthStep + 0 * nChan)[1] + matrix[1, 2] * (copyPtr + (y) * mcopy.widthStep + (1) * nChan)[1] +
                        (matrix[2, 0] + matrix[2, 1]) * (copyPtr + (y + 1) * mcopy.widthStep + 0 * nChan)[1] + matrix[2, 2] * (copyPtr + (y + 1) * mcopy.widthStep + (1) * nChan)[1]) / matrixWeight);

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    red = (int)Math.Round((double)((matrix[0, 0] + matrix[0, 1]) * (copyPtr + (y - 1) * mcopy.widthStep + 0 * nChan)[2] + matrix[0, 2] * (copyPtr + (y - 1) * mcopy.widthStep + (1) * nChan)[2] +
                        (matrix[1, 0] + matrix[1, 1]) * (copyPtr + (y) * mcopy.widthStep + 0 * nChan)[2] + matrix[1, 2] * (copyPtr + (y) * mcopy.widthStep + (1) * nChan)[2] +
                        (matrix[2, 0] + matrix[2, 1]) * (copyPtr + (y + 1) * mcopy.widthStep + 0 * nChan)[2] + matrix[2, 2] * (copyPtr + (y + 1) * mcopy.widthStep + (1) * nChan)[2]) / matrixWeight);

                    if (blue > 0 && blue < 255)

                    {
                        (dataPtr + y * m.widthStep + 0 * nChan)[0] = (byte)blue;
                    }

                    else if (blue <= 0)
                    {
                        (dataPtr + y * m.widthStep + 0 * nChan)[0] = 0;
                    }

                    else if (blue >= 255)
                    {
                        (dataPtr + y * m.widthStep + 0 * nChan)[0] = 255;
                    }

                    if (green > 0 && green < 255)
                    {
                        (dataPtr + y * m.widthStep + 0 * nChan)[1] = (byte)green;
                    }

                    else if (green <= 0)
                    {
                        (dataPtr + y * m.widthStep + 0 * nChan)[1] = 0;
                    }

                    else if (green >= 255)
                    {
                        (dataPtr + y * m.widthStep + 0 * nChan)[1] = 255;
                    }

                    if (red > 0 && red < 255)
                    {
                        (dataPtr + y * m.widthStep + 0 * nChan)[2] = (byte)red;
                    }

                    else if (red <= 0)
                    {
                        (dataPtr + y * m.widthStep + 0 * nChan)[2] = 0;
                    }

                    else if (red >= 255)
                    {
                        (dataPtr + y * m.widthStep + 0 * nChan)[2] = 255;
                    }
                }

                //Margem direita sem cantos
                for (y = 1; y < (height - 1); y++)
                {
                    //cálculo da média na compenente azul para um filtro 3x3
                    blue = (int)Math.Round((double)((matrix[0, 1] + matrix[0, 2]) * (copyPtr + (y - 1) * mcopy.widthStep + (width - 1) * nChan)[0] + matrix[0, 0] * (copyPtr + (y - 1) * mcopy.widthStep + (width - 2) * nChan)[0] +
                        (matrix[1, 1] + matrix[1, 2]) * (copyPtr + (y) * mcopy.widthStep + (width - 1) * nChan)[0] + matrix[1, 0] * (copyPtr + (y) * mcopy.widthStep + (width - 2) * nChan)[0] +
                        (matrix[2, 1] + matrix[2, 2]) * (copyPtr + (y + 1) * mcopy.widthStep + (width - 1) * nChan)[0] + matrix[2, 0] * (copyPtr + (y + 1) * mcopy.widthStep + (width - 2) * nChan)[0]) / matrixWeight);

                    //cálculo da média na compenente verde para um filtro 3x3
                    green = (int)Math.Round((double)((matrix[0, 1] + matrix[0, 2]) * (copyPtr + (y - 1) * mcopy.widthStep + (width - 1) * nChan)[1] + matrix[0, 0] * (copyPtr + (y - 1) * mcopy.widthStep + (width - 2) * nChan)[1] +
                        (matrix[1, 1] + matrix[1, 2]) * (copyPtr + (y) * mcopy.widthStep + (width - 1) * nChan)[1] + matrix[1, 0] * (copyPtr + (y) * mcopy.widthStep + (width - 2) * nChan)[1] +
                        (matrix[2, 1] + matrix[2, 2]) * (copyPtr + (y + 1) * mcopy.widthStep + (width - 1) * nChan)[1] + matrix[2, 0] * (copyPtr + (y + 1) * mcopy.widthStep + (width - 2) * nChan)[1]) / matrixWeight);

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    red = (int)Math.Round((double)((matrix[0, 1] + matrix[0, 2]) * (copyPtr + (y - 1) * mcopy.widthStep + (width - 1) * nChan)[2] + matrix[0, 0] * (copyPtr + (y - 1) * mcopy.widthStep + (width - 2) * nChan)[2] +
                        (matrix[1, 1] + matrix[1, 2]) * (copyPtr + (y) * mcopy.widthStep + (width - 1) * nChan)[2] + matrix[1, 0] * (copyPtr + (y) * mcopy.widthStep + (width - 2) * nChan)[2] +
                        (matrix[2, 1] + matrix[2, 2]) * (copyPtr + (y + 1) * mcopy.widthStep + (width - 1) * nChan)[2] + matrix[2, 0] * (copyPtr + (y + 1) * mcopy.widthStep + (width - 2) * nChan)[2]) / matrixWeight);

                    if (blue > 0 && blue < 255)

                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[0] = (byte)blue;
                    }

                    else if (blue <= 0)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[0] = 0;
                    }

                    else if (blue >= 255)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[0] = 255;
                    }

                    if (green > 0 && green < 255)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[1] = (byte)green;
                    }

                    else if (green <= 0)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[1] = 0;
                    }

                    else if (green >= 255)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[1] = 255;
                    }

                    if (red > 0 && red < 255)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[2] = (byte)red;
                    }

                    else if (red <= 0)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[2] = 0;
                    }

                    else if (red >= 255)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[2] = 255;
                    }
                }

                //Margem superior sem cantos
                for (x = 1; x < (width - 1); x++)
                {
                    //cálculo da média na compenente azul para um filtro 3x3
                    blue = (int)Math.Round((double)((matrix[0, 0] + matrix[1, 0]) * (copyPtr + (0) * mcopy.widthStep + (x - 1) * nChan)[0] + matrix[2, 0] * (copyPtr + (1) * mcopy.widthStep + (x - 1) * nChan)[0] +
                        (matrix[0, 1] + matrix[1, 1]) * (copyPtr + (0) * mcopy.widthStep + x * nChan)[0] + matrix[2, 1] * (copyPtr + (1) * mcopy.widthStep + (x) * nChan)[0] +
                        (matrix[0, 2] + matrix[1, 2]) * (copyPtr + (0) * mcopy.widthStep + (x + 1) * nChan)[0] + matrix[2, 2] * (copyPtr + (1) * mcopy.widthStep + (x + 1) * nChan)[0]) / matrixWeight);

                    //cálculo da média na compenente verde para um filtro 3x3
                    green = (int)Math.Round((double)((matrix[0, 0] + matrix[1, 0]) * (copyPtr + (0) * mcopy.widthStep + (x - 1) * nChan)[1] + matrix[2, 0] * (copyPtr + (1) * mcopy.widthStep + (x - 1) * nChan)[1] +
                        (matrix[0, 1] + matrix[1, 1]) * (copyPtr + (0) * mcopy.widthStep + x * nChan)[1] + matrix[2, 1] * (copyPtr + (1) * mcopy.widthStep + (x) * nChan)[1] +
                        (matrix[0, 2] + matrix[1, 2]) * (copyPtr + (0) * mcopy.widthStep + (x + 1) * nChan)[1] + matrix[2, 2] * (copyPtr + (1) * mcopy.widthStep + (x + 1) * nChan)[1]) / matrixWeight);

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    red = (int)Math.Round((double)((matrix[0, 0] + matrix[1, 0]) * (copyPtr + (0) * mcopy.widthStep + (x - 1) * nChan)[2] + matrix[2, 0] * (copyPtr + (1) * mcopy.widthStep + (x - 1) * nChan)[2] +
                        (matrix[0, 1] + matrix[1, 1]) * (copyPtr + (0) * mcopy.widthStep + x * nChan)[2] + matrix[2, 1] * (copyPtr + (1) * mcopy.widthStep + (x) * nChan)[2] +
                        (matrix[0, 2] + matrix[1, 2]) * (copyPtr + (0) * mcopy.widthStep + (x + 1) * nChan)[2] + matrix[2, 2] * (copyPtr + (1) * mcopy.widthStep + (x + 1) * nChan)[2]) / matrixWeight);

                    if (blue > 0 && blue < 255)

                    {
                        (dataPtr + 0 * m.widthStep + x * nChan)[0] = (byte)blue;
                    }

                    else if (blue <= 0)
                    {
                        (dataPtr + 0 * m.widthStep + x * nChan)[0] = 0;
                    }

                    else if (blue >= 255)
                    {
                        (dataPtr + 0 * m.widthStep + x * nChan)[0] = 255;
                    }

                    if (green > 0 && green < 255)
                    {
                        (dataPtr + 0 * m.widthStep + x * nChan)[1] = (byte)green;
                    }

                    else if (green <= 0)
                    {
                        (dataPtr + 0 * m.widthStep + x * nChan)[1] = 0;
                    }

                    else if (green >= 255)
                    {
                        (dataPtr + 0 * m.widthStep + x * nChan)[1] = 255;
                    }

                    if (red > 0 && red < 255)
                    {
                        (dataPtr + 0 * m.widthStep + x * nChan)[2] = (byte)red;
                    }

                    else if (red <= 0)
                    {
                        (dataPtr + 0 * m.widthStep + x * nChan)[2] = 0;
                    }

                    else if (red >= 255)
                    {
                        (dataPtr + 0 * m.widthStep + x * nChan)[2] = 255;
                    }
                }

                //Margem inferior sem cantos
                for (x = 1; x < (width - 1); x++)
                {
                    //cálculo da média na compenente azul para um filtro 3x3
                    blue = (int)Math.Round((double)((matrix[1, 0] + matrix[2, 0]) * (copyPtr + (height - 1) * mcopy.widthStep + (x - 1) * nChan)[0] + matrix[0, 0] * (copyPtr + (height - 2) * mcopy.widthStep + (x - 1) * nChan)[0] +
                        (matrix[1, 1] + matrix[2, 1]) * (copyPtr + (height - 1) * mcopy.widthStep + x * nChan)[0] + matrix[0, 1] * (copyPtr + (height - 2) * mcopy.widthStep + (x) * nChan)[0] +
                        (matrix[1, 2] + matrix[2, 2]) * (copyPtr + (height - 1) * mcopy.widthStep + (x + 1) * nChan)[0] + matrix[0, 2] * (copyPtr + (height - 2) * mcopy.widthStep + (x + 1) * nChan)[0]) / matrixWeight);

                    //cálculo da média na compenente verde para um filtro 3x3
                    green = (int)Math.Round((double)((matrix[1, 0] + matrix[2, 0]) * (copyPtr + (height - 1) * mcopy.widthStep + (x - 1) * nChan)[1] + matrix[0, 0] * (copyPtr + (height - 2) * mcopy.widthStep + (x - 1) * nChan)[1] +
                        (matrix[1, 1] + matrix[2, 1]) * (copyPtr + (height - 1) * mcopy.widthStep + x * nChan)[1] + matrix[0, 1] * (copyPtr + (height - 2) * mcopy.widthStep + (x) * nChan)[1] +
                        (matrix[1, 2] + matrix[2, 2]) * (copyPtr + (height - 1) * mcopy.widthStep + (x + 1) * nChan)[1] + matrix[0, 2] * (copyPtr + (height - 2) * mcopy.widthStep + (x + 1) * nChan)[1]) / matrixWeight);

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    red = (int)Math.Round((double)((matrix[1, 0] + matrix[2, 0]) * (copyPtr + (height - 1) * mcopy.widthStep + (x - 1) * nChan)[2] + matrix[0, 0] * (copyPtr + (height - 2) * mcopy.widthStep + (x - 1) * nChan)[2] +
                        (matrix[1, 1] + matrix[2, 1]) * (copyPtr + (height - 1) * mcopy.widthStep + x * nChan)[2] + matrix[0, 1] * (copyPtr + (height - 2) * mcopy.widthStep + (x) * nChan)[2] +
                        (matrix[1, 2] + matrix[2, 2]) * (copyPtr + (height - 1) * mcopy.widthStep + (x + 1) * nChan)[2] + matrix[0, 2] * (copyPtr + (height - 2) * mcopy.widthStep + (x + 1) * nChan)[2]) / matrixWeight);

                    if (blue > 0 && blue < 255)

                    {
                        (dataPtr + (height - 1) * m.widthStep + x * nChan)[0] = (byte)blue;
                    }

                    else if (blue <= 0)
                    {
                        (dataPtr + (height - 1) * m.widthStep + x * nChan)[0] = 0;
                    }

                    else if (blue >= 255)
                    {
                        (dataPtr + (height - 1) * m.widthStep + x * nChan)[0] = 255;
                    }

                    if (green > 0 && green < 255)
                    {
                        (dataPtr + (height - 1) * m.widthStep + x * nChan)[1] = (byte)green;
                    }

                    else if (green <= 0)
                    {
                        (dataPtr + (height - 1) * m.widthStep + x * nChan)[1] = 0;
                    }

                    else if (green >= 255)
                    {
                        (dataPtr + (height - 1) * m.widthStep + x * nChan)[1] = 255;
                    }

                    if (red > 0 && red < 255)
                    {
                        (dataPtr + (height - 1) * m.widthStep + x * nChan)[2] = (byte)red;
                    }

                    else if (red <= 0)
                    {
                        (dataPtr + (height - 1) * m.widthStep + x * nChan)[2] = 0;
                    }

                    else if (red >= 255)
                    {
                        (dataPtr + (height - 1) * m.widthStep + x * nChan)[2] = 255;
                    }
                }

                //Canto Superior Esquerdo

                //cálculo da média na compenente azul para um filtro 3x3
                blue = (int)Math.Round((double)((matrix[0, 0] + matrix[0, 1] + matrix[1, 0] + matrix[1, 1]) * (copyPtr + (0) * mcopy.widthStep + (0) * nChan)[0] +
                    (matrix[0, 2] + matrix[1, 2]) * (copyPtr + (0) * mcopy.widthStep + 1 * nChan)[0] +
                    (matrix[2, 0] + matrix[2, 1]) * (copyPtr + (1) * mcopy.widthStep + (0) * nChan)[0] + matrix[2, 2] * (copyPtr + (1) * mcopy.widthStep + (1) * nChan)[0]) / matrixWeight);

                //cálculo da média na compenente verde para um filtro 3x3
                green = (int)Math.Round((double)((matrix[0, 0] + matrix[0, 1] + matrix[1, 0] + matrix[1, 1]) * (copyPtr + (0) * mcopy.widthStep + (0) * nChan)[1] +
                    (matrix[0, 2] + matrix[1, 2]) * (copyPtr + (0) * mcopy.widthStep + 1 * nChan)[1] +
                    (matrix[2, 0] + matrix[2, 1]) * (copyPtr + (1) * mcopy.widthStep + (0) * nChan)[1] + matrix[2, 2] * (copyPtr + (1) * mcopy.widthStep + (1) * nChan)[1]) / matrixWeight);

                //cálculo da média na compenente vermelha para um filtro 3x3
                red = (int)Math.Round((double)((matrix[0, 0] + matrix[0, 1] + matrix[1, 0] + matrix[1, 1]) * (copyPtr + (0) * mcopy.widthStep + (0) * nChan)[2] +
                    (matrix[0, 2] + matrix[1, 2]) * (copyPtr + (0) * mcopy.widthStep + 1 * nChan)[2] +
                    (matrix[2, 0] + matrix[2, 1]) * (copyPtr + (1) * mcopy.widthStep + (0) * nChan)[2] + matrix[2, 2] * (copyPtr + (1) * mcopy.widthStep + (1) * nChan)[2]) / matrixWeight);

                if (blue > 0 && blue < 255)

                {
                    (dataPtr + 0 * m.widthStep + 0 * nChan)[0] = (byte)blue;
                }

                else if (blue <= 0)
                {
                    (dataPtr + 0 * m.widthStep + 0 * nChan)[0] = 0;
                }

                else if (blue >= 255)
                {
                    (dataPtr + 0 * m.widthStep + 0 * nChan)[0] = 255;
                }

                if (green > 0 && green < 255)
                {
                    (dataPtr + 0 * m.widthStep + 0 * nChan)[1] = (byte)green;
                }

                else if (green <= 0)
                {
                    (dataPtr + 0 * m.widthStep + 0 * nChan)[1] = 0;
                }

                else if (green >= 255)
                {
                    (dataPtr + 0 * m.widthStep + 0 * nChan)[1] = 255;
                }

                if (red > 0 && red < 255)
                {
                    (dataPtr + 0 * m.widthStep + 0 * nChan)[2] = (byte)red;
                }

                else if (red <= 0)
                {
                    (dataPtr + 0 * m.widthStep + 0 * nChan)[2] = 0;
                }

                else if (red >= 255)
                {
                    (dataPtr + 0 * m.widthStep + 0 * nChan)[2] = 255;
                }


                //Canto Superior Direito

                //cálculo da média na compenente azul para um filtro 3x3
                blue = (int)Math.Round((double)((matrix[0, 2] + matrix[0, 1] + matrix[1, 2] + matrix[1, 1]) * (copyPtr + (0) * mcopy.widthStep + (width - 1) * nChan)[0] +
                    (matrix[0, 0] + matrix[1, 0]) * (copyPtr + (0) * mcopy.widthStep + (width - 2) * nChan)[0] +
                    (matrix[2, 1] + matrix[2, 2]) * (copyPtr + (1) * mcopy.widthStep + (width - 1) * nChan)[0] + matrix[2, 0] * (copyPtr + (1) * mcopy.widthStep + (width - 2) * nChan)[0]) / matrixWeight);

                //cálculo da média na compenente verde para um filtro 3x3
                green = (int)Math.Round((double)((matrix[0, 2] + matrix[0, 1] + matrix[1, 2] + matrix[1, 1]) * (copyPtr + (0) * mcopy.widthStep + (width - 1) * nChan)[1] +
                    (matrix[0, 0] + matrix[1, 0]) * (copyPtr + (0) * mcopy.widthStep + (width - 2) * nChan)[1] +
                    (matrix[2, 1] + matrix[2, 2]) * (copyPtr + (1) * mcopy.widthStep + (width - 1) * nChan)[1] + matrix[2, 0] * (copyPtr + (1) * mcopy.widthStep + (width - 2) * nChan)[1]) / matrixWeight);

                //cálculo da média na compenente vermelha para um filtro 3x3
                red = (int)Math.Round((double)((matrix[0, 2] + matrix[0, 1] + matrix[1, 2] + matrix[1, 1]) * (copyPtr + (0) * mcopy.widthStep + (width - 1) * nChan)[2] +
                    (matrix[0, 0] + matrix[1, 0]) * (copyPtr + (0) * mcopy.widthStep + (width - 2) * nChan)[2] +
                    (matrix[2, 1] + matrix[2, 2]) * (copyPtr + (1) * mcopy.widthStep + (width - 1) * nChan)[2] + matrix[2, 0] * (copyPtr + (1) * mcopy.widthStep + (width - 2) * nChan)[2]) / matrixWeight);


                if (blue <= 0)
                {
                    blue = 0;
                }

                else if (blue >= 255)
                {
                    blue = 255;
                }

                (dataPtr + 0 * m.widthStep + (width - 1) * nChan)[0] = (byte)blue;

                if (green <= 0)
                {
                    green = 0;
                }

                else if (green >= 255)
                {
                    green = 255;
                }

                (dataPtr + 0 * m.widthStep + (width - 1) * nChan)[1] = (byte)green;

                if (red <= 0)
                {
                    red = 0;
                }

                else if (red >= 255)
                {
                    red = 255;
                }

                (dataPtr + 0 * m.widthStep + (width - 1) * nChan)[2] = (byte)red;

                //Canto Inferior Esquerdo

                //cálculo da média na compenente azul para um filtro 3x3
                blue = (int)Math.Round((double)((matrix[2, 0] + matrix[2, 1] + matrix[1, 0] + matrix[1, 1]) * (copyPtr + (height - 1) * mcopy.widthStep + (0) * nChan)[0] +
                    (matrix[1, 2] + matrix[2, 2]) * (copyPtr + (height - 1) * mcopy.widthStep + (1) * nChan)[0] +
                    (matrix[0, 0] + matrix[0, 1]) * (copyPtr + (height - 2) * mcopy.widthStep + (0) * nChan)[0] + matrix[0, 2] * (copyPtr + (height - 2) * mcopy.widthStep + (1) * nChan)[0]) / matrixWeight);

                //cálculo da média na compenente verde para um filtro 3x3
                green = (int)Math.Round((double)((matrix[2, 0] + matrix[2, 1] + matrix[1, 0] + matrix[1, 1]) * (copyPtr + (height - 1) * mcopy.widthStep + (0) * nChan)[1] +
                    (matrix[1, 2] + matrix[2, 2]) * (copyPtr + (height - 1) * mcopy.widthStep + (1) * nChan)[1] +
                    (matrix[0, 0] + matrix[0, 1]) * (copyPtr + (height - 2) * mcopy.widthStep + (0) * nChan)[1] + matrix[0, 2] * (copyPtr + (height - 2) * mcopy.widthStep + (1) * nChan)[1]) / matrixWeight);

                //cálculo da média na compenente vermelha para um filtro 3x3
                red = (int)Math.Round((double)((matrix[2, 0] + matrix[2, 1] + matrix[1, 0] + matrix[1, 1]) * (copyPtr + (height - 1) * mcopy.widthStep + (0) * nChan)[2] +
                    (matrix[1, 2] + matrix[2, 2]) * (copyPtr + (height - 1) * mcopy.widthStep + (1) * nChan)[2] +
                    (matrix[0, 0] + matrix[0, 1]) * (copyPtr + (height - 2) * mcopy.widthStep + (0) * nChan)[2] + matrix[0, 2] * (copyPtr + (height - 2) * mcopy.widthStep + (1) * nChan)[2]) / matrixWeight);

                if (blue > 0 && blue < 255)

                {
                    (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[0] = (byte)blue;
                }

                else if (blue <= 0)
                {
                    (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[0] = 0;
                }

                else if (blue >= 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[0] = 255;
                }

                if (green > 0 && green < 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[1] = (byte)green;
                }

                else if (green <= 0)
                {
                    (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[1] = 0;
                }

                else if (green >= 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[1] = 255;
                }

                if (red > 0 && red < 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[2] = (byte)red;
                }

                else if (red <= 0)
                {
                    (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[2] = 0;
                }

                else if (red >= 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[2] = 255;
                }

                //Canto Inferior Direito

                //cálculo da média na compenente azul para um filtro 3x3
                blue = (int)Math.Round((double)((matrix[2, 2] + matrix[2, 1] + matrix[1, 2] + matrix[1, 1]) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 1) * nChan)[0] +
                    (matrix[1, 0] + matrix[2, 0]) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 2) * nChan)[0] +
                    (matrix[0, 1] + matrix[0, 2]) * (copyPtr + (height - 2) * mcopy.widthStep + (width - 1) * nChan)[0] + matrix[0, 0] * (copyPtr + (height - 2) * mcopy.widthStep + (width - 2) * nChan)[0]) / matrixWeight);

                //cálculo da média na compenente verde para um filtro 3x3
                green = (int)Math.Round((double)((matrix[2, 2] + matrix[2, 1] + matrix[1, 2] + matrix[1, 1]) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 1) * nChan)[1] +
                    (matrix[1, 0] + matrix[2, 0]) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 2) * nChan)[1] +
                    (matrix[0, 1] + matrix[0, 2]) * (copyPtr + (height - 2) * mcopy.widthStep + (width - 1) * nChan)[1] + matrix[0, 0] * (copyPtr + (height - 2) * mcopy.widthStep + (width - 2) * nChan)[1]) / matrixWeight);

                //cálculo da média na compenente vermelha para um filtro 3x3
                red = (int)Math.Round((double)((matrix[2, 2] + matrix[2, 1] + matrix[1, 2] + matrix[1, 1]) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 1) * nChan)[2] +
                    (matrix[1, 0] + matrix[2, 0]) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 2) * nChan)[2] +
                    (matrix[0, 1] + matrix[0, 2]) * (copyPtr + (height - 2) * mcopy.widthStep + (width - 1) * nChan)[2] + matrix[0, 0] * (copyPtr + (height - 2) * mcopy.widthStep + (width - 2) * nChan)[2]) / matrixWeight);

                if (blue > 0 && blue < 255)

                {
                    (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[0] = (byte)blue;
                }

                else if (blue <= 0)
                {
                    (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[0] = 0;
                }

                else if (blue >= 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[0] = 255;
                }

                if (green > 0 && green < 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[1] = (byte)green;
                }

                else if (green <= 0)
                {
                    (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[1] = 0;
                }

                else if (green >= 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[1] = 255;
                }

                if (red > 0 && red < 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[2] = (byte)red;
                }

                else if (red <= 0)
                {
                    (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[2] = 0;
                }

                else if (red >= 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[2] = 255;
                }
            }
        }

        public static void Sobel(Image<Bgr, byte> img, Image<Bgr, byte> imgCopy)
        {
            unsafe
            {
                MIplImage m = img.MIplImage;
                MIplImage mcopy = imgCopy.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer();
                byte* copyPtr = (byte*)mcopy.imageData.ToPointer();
                int SXblue, SXgreen, SXred, SYblue, SYgreen, SYred, blue, green, red;
                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels;
                int x, y;

                for (y = 1; y < (height - 1); y++)
                {
                    for (x = 1; x < (width - 1); x++)
                    {
                        //cálculo da média na compenente azul para um filtro 3x3
                        SXblue = (int)Math.Round((double)(((copyPtr + (y - 1) * mcopy.widthStep + (x - 1) * nChan)[0] * 1 +
                            (copyPtr + (y - 1) * mcopy.widthStep + x * nChan)[0] * 0 + (copyPtr + (y - 1) * mcopy.widthStep + (x + 1) * nChan)[0] * (-1) +
                            (copyPtr + (y) * mcopy.widthStep + (x - 1) * nChan)[0] * 2 +
                            (copyPtr + (y) * mcopy.widthStep + x * nChan)[0] * 0 + (copyPtr + (y) * mcopy.widthStep + (x + 1) * nChan)[0] * (-2) +
                            (copyPtr + (y + 1) * mcopy.widthStep + (x - 1) * nChan)[0] * 1 +
                            (copyPtr + (y + 1) * mcopy.widthStep + x * nChan)[0] * 0 + (copyPtr + (y + 1) * mcopy.widthStep + (x + 1) * nChan)[0] * -1) / 1));

                        //cálculo da média na compenente verde para um filtro 3x3
                        SXgreen = (int)Math.Round((double)(((copyPtr + (y - 1) * mcopy.widthStep + (x - 1) * nChan)[1] * 1 +
                            (copyPtr + (y - 1) * mcopy.widthStep + x * nChan)[1] * 0 + (copyPtr + (y - 1) * mcopy.widthStep + (x + 1) * nChan)[1] * (-1) +
                            (copyPtr + (y) * mcopy.widthStep + (x - 1) * nChan)[1] * 2 +
                            (copyPtr + (y) * mcopy.widthStep + x * nChan)[1] * 0 + (copyPtr + (y) * mcopy.widthStep + (x + 1) * nChan)[1] * (-2) +
                            (copyPtr + (y + 1) * mcopy.widthStep + (x - 1) * nChan)[1] * 1 +
                            (copyPtr + (y + 1) * mcopy.widthStep + x * nChan)[1] * 0 + (copyPtr + (y + 1) * mcopy.widthStep + (x + 1) * nChan)[1] * -1) / 1));

                        //cálculo da média na compenente vermelha para um filtro 3x3
                        SXred = (int)Math.Round((double)(((copyPtr + (y - 1) * mcopy.widthStep + (x - 1) * nChan)[2] * 1 +
                            (copyPtr + (y - 1) * mcopy.widthStep + x * nChan)[2] * 0 + (copyPtr + (y - 1) * mcopy.widthStep + (x + 1) * nChan)[2] * (-1) +
                            (copyPtr + (y) * mcopy.widthStep + (x - 1) * nChan)[2] * 2 +
                            (copyPtr + (y) * mcopy.widthStep + x * nChan)[2] * 0 + (copyPtr + (y) * mcopy.widthStep + (x + 1) * nChan)[2] * (-2) +
                            (copyPtr + (y + 1) * mcopy.widthStep + (x - 1) * nChan)[2] * 1 +
                            (copyPtr + (y + 1) * mcopy.widthStep + x * nChan)[2] * 0 + (copyPtr + (y + 1) * mcopy.widthStep + (x + 1) * nChan)[2] * -1) / 1));

                        //cálculo da média na compenente azul para um filtro 3x3
                        SYblue = (int)Math.Round((double)(((copyPtr + (y - 1) * mcopy.widthStep + (x - 1) * nChan)[0] * -1 +
                            (copyPtr + (y - 1) * mcopy.widthStep + x * nChan)[0] * -2 + (copyPtr + (y - 1) * mcopy.widthStep + (x + 1) * nChan)[0] * (-1) +
                            (copyPtr + (y) * mcopy.widthStep + (x - 1) * nChan)[0] * 0 +
                            (copyPtr + (y) * mcopy.widthStep + x * nChan)[0] * 0 + (copyPtr + (y) * mcopy.widthStep + (x + 1) * nChan)[0] * (0) +
                            (copyPtr + (y + 1) * mcopy.widthStep + (x - 1) * nChan)[0] * 1 +
                            (copyPtr + (y + 1) * mcopy.widthStep + x * nChan)[0] * 2 + (copyPtr + (y + 1) * mcopy.widthStep + (x + 1) * nChan)[0] * 1) / 1));

                        SYgreen = (int)Math.Round((double)(((copyPtr + (y - 1) * mcopy.widthStep + (x - 1) * nChan)[1] * -1 +
                            (copyPtr + (y - 1) * mcopy.widthStep + x * nChan)[1] * -2 + (copyPtr + (y - 1) * mcopy.widthStep + (x + 1) * nChan)[1] * (-1) +
                            (copyPtr + (y) * mcopy.widthStep + (x - 1) * nChan)[1] * 0 +
                            (copyPtr + (y) * mcopy.widthStep + x * nChan)[1] * 0 + (copyPtr + (y) * mcopy.widthStep + (x + 1) * nChan)[1] * (0) +
                            (copyPtr + (y + 1) * mcopy.widthStep + (x - 1) * nChan)[1] * 1 +
                            (copyPtr + (y + 1) * mcopy.widthStep + x * nChan)[1] * 2 + (copyPtr + (y + 1) * mcopy.widthStep + (x + 1) * nChan)[1] * 1) / 1));

                        SYred = (int)Math.Round((double)(((copyPtr + (y - 1) * mcopy.widthStep + (x - 1) * nChan)[2] * -1 +
                            (copyPtr + (y - 1) * mcopy.widthStep + x * nChan)[2] * -2 + (copyPtr + (y - 1) * mcopy.widthStep + (x + 1) * nChan)[2] * (-1) +
                            (copyPtr + (y) * mcopy.widthStep + (x - 1) * nChan)[2] * 0 +
                            (copyPtr + (y) * mcopy.widthStep + x * nChan)[2] * 0 + (copyPtr + (y) * mcopy.widthStep + (x + 1) * nChan)[2] * (0) +
                            (copyPtr + (y + 1) * mcopy.widthStep + (x - 1) * nChan)[2] * 1 +
                            (copyPtr + (y + 1) * mcopy.widthStep + x * nChan)[2] * 2 + (copyPtr + (y + 1) * mcopy.widthStep + (x + 1) * nChan)[2] * 1) / 1));

                        blue = Math.Abs(SXblue) + Math.Abs(SYblue);
                        green = Math.Abs(SXgreen) + Math.Abs(SYgreen);
                        red = Math.Abs(SXred) + Math.Abs(SYred);


                        if (blue < 255)

                        {
                            (dataPtr + y * m.widthStep + x * nChan)[0] = (byte)blue;
                        }

                        else if (blue >= 255)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[0] = 255;
                        }

                        if (green < 255)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[1] = (byte)green;
                        }


                        else if (green >= 255)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[1] = 255;
                        }

                        if (red < 255)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[2] = (byte)red;
                        }

                        else if (red >= 255)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[2] = 255;
                        }
                    }
                }

                //Margem esquerda sem cantos
                for (y = 1; y < (height - 1); y++)
                {
                    //cálculo da média na compenente azul para um filtro 3x3
                    SXblue = (int)Math.Round((double)((copyPtr + (y - 1) * mcopy.widthStep)[0] - (copyPtr + (y - 1) * mcopy.widthStep + nChan)[0] +
                        2 * (copyPtr + y * mcopy.widthStep)[0] - 2 * (copyPtr + y * mcopy.widthStep + nChan)[0] +
                        1 * (copyPtr + (y + 1) * mcopy.widthStep)[0] + (-1) * (copyPtr + (y + 1) * mcopy.widthStep + nChan)[0]));

                    //cálculo da média na compenente verde para um filtro 3x3
                    SXgreen = (int)Math.Round((double)((copyPtr + (y - 1) * mcopy.widthStep)[1] - (copyPtr + (y - 1) * mcopy.widthStep + nChan)[1] +
                        2 * (copyPtr + y * mcopy.widthStep)[1] - 2 * (copyPtr + y * mcopy.widthStep + nChan)[1] +
                        1 * (copyPtr + (y + 1) * mcopy.widthStep)[1] + (-1) * (copyPtr + (y + 1) * mcopy.widthStep + nChan)[1]));

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    SXred = (int)Math.Round((double)((copyPtr + (y - 1) * mcopy.widthStep)[2] - (copyPtr + (y - 1) * mcopy.widthStep + nChan)[2] +
                        2 * (copyPtr + y * mcopy.widthStep)[2] - 2 * (copyPtr + y * mcopy.widthStep + nChan)[2] +
                        1 * (copyPtr + (y + 1) * mcopy.widthStep)[2] + (-1) * (copyPtr + (y + 1) * mcopy.widthStep + nChan)[2]));

                    //cálculo da média na compenente azul para um filtro 3x3
                    SYblue = (int)Math.Round((double)((-3) * (copyPtr + (y - 1) * mcopy.widthStep)[0] - (copyPtr + (y - 1) * mcopy.widthStep + nChan)[0] +
                        3 * (copyPtr + (y + 1) * mcopy.widthStep)[0] +  (copyPtr + (y + 1) * mcopy.widthStep + nChan)[0]));

                    //cálculo da média na compenente verde para um filtro 3x3
                    SYgreen = (int)Math.Round((double)((-3) * (copyPtr + (y - 1) * mcopy.widthStep)[1] - (copyPtr + (y - 1) * mcopy.widthStep + nChan)[1] +
                        3 * (copyPtr + (y + 1) * mcopy.widthStep)[1] + (copyPtr + (y + 1) * mcopy.widthStep + nChan)[1]));

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    SYred = (int)Math.Round((double)((-3) * (copyPtr + (y - 1) * mcopy.widthStep)[2] - (copyPtr + (y - 1) * mcopy.widthStep + nChan)[2] +
                        3 * (copyPtr + (y + 1) * mcopy.widthStep)[2] + (copyPtr + (y + 1) * mcopy.widthStep + nChan)[2]));

                    blue = Math.Abs(SXblue) + Math.Abs(SYblue);
                    green = Math.Abs(SXgreen) + Math.Abs(SYgreen);
                    red = Math.Abs(SXred) + Math.Abs(SYred);

                    if (blue > 255)

                    {
                        blue = 255;
                    }

                    (dataPtr + y * m.widthStep + 0 * nChan)[0] = (byte)blue;

                    if (green > 255)
                    {
                        green = 255;
                    }

                    (dataPtr + y * m.widthStep + 0 * nChan)[1] = (byte)green;

                    if (red > 255)
                    {
                        red = 255;
                    }

                    (dataPtr + y * m.widthStep + 0 * nChan)[2] = (byte)red;
                }

                //Margem direita sem cantos
                for (y = 1; y < (height - 1); y++)
                {
                    //cálculo da média na compenente azul para um filtro 3x3
                    SXblue = (int)Math.Round((double)(((0 + -1) * (copyPtr + (y - 1) * mcopy.widthStep + (width - 1) * nChan)[0] + 1 * (copyPtr + (y - 1) * mcopy.widthStep + (width - 2) * nChan)[0] +
                        (0 + -2) * (copyPtr + (y) * mcopy.widthStep + (width - 1) * nChan)[0] + 2 * (copyPtr + (y) * mcopy.widthStep + (width - 2) * nChan)[0] +
                        (0 + -1) * (copyPtr + (y + 1) * mcopy.widthStep + (width - 1) * nChan)[0] + 1 * (copyPtr + (y + 1) * mcopy.widthStep + (width - 2) * nChan)[0]) / 1));

                    //cálculo da média na compenente verde para um filtro 3x3
                    SXgreen = (int)Math.Round((double)(((0 + -1) * (copyPtr + (y - 1) * mcopy.widthStep + (width - 1) * nChan)[1] + 1 * (copyPtr + (y - 1) * mcopy.widthStep + (width - 2) * nChan)[1] +
                        (0 + -2) * (copyPtr + (y) * mcopy.widthStep + (width - 1) * nChan)[1] + 2 * (copyPtr + (y) * mcopy.widthStep + (width - 2) * nChan)[1] +
                        (0 + -1) * (copyPtr + (y + 1) * mcopy.widthStep + (width - 1) * nChan)[1] + 1 * (copyPtr + (y + 1) * mcopy.widthStep + (width - 2) * nChan)[1]) / 1));

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    SXred = (int)Math.Round((double)(((0 + -1) * (copyPtr + (y - 1) * mcopy.widthStep + (width - 1) * nChan)[2] + 1 * (copyPtr + (y - 1) * mcopy.widthStep + (width - 2) * nChan)[2] +
                        (0 + -2) * (copyPtr + (y) * mcopy.widthStep + (width - 1) * nChan)[2] + 2 * (copyPtr + (y) * mcopy.widthStep + (width - 2) * nChan)[2] +
                        (0 + -1) * (copyPtr + (y + 1) * mcopy.widthStep + (width - 1) * nChan)[2] + 1 * (copyPtr + (y + 1) * mcopy.widthStep + (width - 2) * nChan)[2]) / 1));

                    //cálculo da média na compenente azul para um filtro 3x3
                    SYblue = (int)Math.Round((double)(((-2 + -1) * (copyPtr + (y - 1) * mcopy.widthStep + (width - 1) * nChan)[0] + -1 * (copyPtr + (y - 1) * mcopy.widthStep + (width - 2) * nChan)[0] +
                        (0 + 0) * (copyPtr + (y) * mcopy.widthStep + (width - 1) * nChan)[0] + 0 * (copyPtr + (y) * mcopy.widthStep + (width - 2) * nChan)[0] +
                        (2 + 1) * (copyPtr + (y + 1) * mcopy.widthStep + (width - 1) * nChan)[0] + 1 * (copyPtr + (y + 1) * mcopy.widthStep + (width - 2) * nChan)[0]) / 1));

                    //cálculo da média na compenente verde para um filtro 3x3
                    SYgreen = (int)Math.Round((double)(((-2 + -1) * (copyPtr + (y - 1) * mcopy.widthStep + (width - 1) * nChan)[1] + -1 * (copyPtr + (y - 1) * mcopy.widthStep + (width - 2) * nChan)[1] +
                        (0 + 0) * (copyPtr + (y) * mcopy.widthStep + (width - 1) * nChan)[1] + 0 * (copyPtr + (y) * mcopy.widthStep + (width - 2) * nChan)[1] +
                        (2 + 1) * (copyPtr + (y + 1) * mcopy.widthStep + (width - 1) * nChan)[1] + 1 * (copyPtr + (y + 1) * mcopy.widthStep + (width - 2) * nChan)[1]) / 1));

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    SYred = (int)Math.Round((double)(((-2 + -1) * (copyPtr + (y - 1) * mcopy.widthStep + (width - 1) * nChan)[2] + -1 * (copyPtr + (y - 1) * mcopy.widthStep + (width - 2) * nChan)[2] +
                        (0 + 0) * (copyPtr + (y) * mcopy.widthStep + (width - 1) * nChan)[2] + 0 * (copyPtr + (y) * mcopy.widthStep + (width - 2) * nChan)[2] +
                        (2 + 1) * (copyPtr + (y + 1) * mcopy.widthStep + (width - 1) * nChan)[2] + 1 * (copyPtr + (y + 1) * mcopy.widthStep + (width - 2) * nChan)[2]) / 1));

                    blue = Math.Abs(SXblue) + Math.Abs(SYblue);
                    green = Math.Abs(SXgreen) + Math.Abs(SYgreen);
                    red = Math.Abs(SXred) + Math.Abs(SYred);

                    if (blue < 255)

                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[0] = (byte)blue;
                    }

                    else if (blue >= 255)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[0] = 255;
                    }

                    if (green < 255)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[1] = (byte)green;
                    }

                    else if (green >= 255)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[1] = 255;
                    }

                    if (red < 255)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[2] = (byte)red;
                    }

                    else if (red >= 255)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[2] = 255;
                    }
                }

                //Margem superior sem cantos
                for (x = 1; x < (width - 1); x++)
                {
                    //cálculo da média na compenente azul para um filtro 3x3
                    SXblue = (int)Math.Round((double)(((1 + 2) * (copyPtr + (0) * mcopy.widthStep + (x - 1) * nChan)[0] + 1 * (copyPtr + (1) * mcopy.widthStep + (x - 1) * nChan)[0] +
                        (0 + 0) * (copyPtr + (0) * mcopy.widthStep + x * nChan)[0] + 0 * (copyPtr + (1) * mcopy.widthStep + (x) * nChan)[0] +
                        (-1 + -2) * (copyPtr + (0) * mcopy.widthStep + (x + 1) * nChan)[0] + -1 * (copyPtr + (1) * mcopy.widthStep + (x + 1) * nChan)[0]) / 1));

                    //cálculo da média na compenente verde para um filtro 3x3
                    SXgreen = (int)Math.Round((double)(((1 + 2) * (copyPtr + (0) * mcopy.widthStep + (x - 1) * nChan)[1] + 1 * (copyPtr + (1) * mcopy.widthStep + (x - 1) * nChan)[1] +
                        (0 + 0) * (copyPtr + (0) * mcopy.widthStep + x * nChan)[1] + 0 * (copyPtr + (1) * mcopy.widthStep + (x) * nChan)[1] +
                        (-1 + -2) * (copyPtr + (0) * mcopy.widthStep + (x + 1) * nChan)[1] + -1 * (copyPtr + (1) * mcopy.widthStep + (x + 1) * nChan)[1]) / 1));

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    SXred = (int)Math.Round((double)(((1 + 2) * (copyPtr + (0) * mcopy.widthStep + (x - 1) * nChan)[2] + 1 * (copyPtr + (1) * mcopy.widthStep + (x - 1) * nChan)[2] +
                        (0 + 0) * (copyPtr + (0) * mcopy.widthStep + x * nChan)[2] + 0 * (copyPtr + (1) * mcopy.widthStep + (x) * nChan)[2] +
                        (-1 + -2) * (copyPtr + (0) * mcopy.widthStep + (x + 1) * nChan)[2] + -1 * (copyPtr + (1) * mcopy.widthStep + (x + 1) * nChan)[2]) / 1));

                    //cálculo da média na compenente azul para um filtro 3x3
                    SYblue = (int)Math.Round((double)(((-1 + 0) * (copyPtr + (0) * mcopy.widthStep + (x - 1) * nChan)[0] + 1 * (copyPtr + (1) * mcopy.widthStep + (x - 1) * nChan)[0] +
                        (-2 + 0) * (copyPtr + (0) * mcopy.widthStep + x * nChan)[0] + 2 * (copyPtr + (1) * mcopy.widthStep + (x) * nChan)[0] +
                        (-1 + 0) * (copyPtr + (0) * mcopy.widthStep + (x + 1) * nChan)[0] + 1 * (copyPtr + (1) * mcopy.widthStep + (x + 1) * nChan)[0]) / 1));

                    //cálculo da média na compenente verde para um filtro 3x3
                    SYgreen = (int)Math.Round((double)(((-1 + 0) * (copyPtr + (0) * mcopy.widthStep + (x - 1) * nChan)[1] + 1 * (copyPtr + (1) * mcopy.widthStep + (x - 1) * nChan)[1] +
                        (-2 + 0) * (copyPtr + (0) * mcopy.widthStep + x * nChan)[1] + 2 * (copyPtr + (1) * mcopy.widthStep + (x) * nChan)[1] +
                        (-1 + 0) * (copyPtr + (0) * mcopy.widthStep + (x + 1) * nChan)[1] + 1 * (copyPtr + (1) * mcopy.widthStep + (x + 1) * nChan)[1]) / 1));

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    SYred = (int)Math.Round((double)(((-1 + 0) * (copyPtr + (0) * mcopy.widthStep + (x - 1) * nChan)[2] + 1 * (copyPtr + (1) * mcopy.widthStep + (x - 1) * nChan)[2] +
                        (-2 + 0) * (copyPtr + (0) * mcopy.widthStep + x * nChan)[2] + 2 * (copyPtr + (1) * mcopy.widthStep + (x) * nChan)[2] +
                        (-1 + 0) * (copyPtr + (0) * mcopy.widthStep + (x + 1) * nChan)[2] + 1 * (copyPtr + (1) * mcopy.widthStep + (x + 1) * nChan)[2]) / 1));

                    blue = Math.Abs(SXblue) + Math.Abs(SYblue);
                    green = Math.Abs(SXgreen) + Math.Abs(SYgreen);
                    red = Math.Abs(SXred) + Math.Abs(SYred);

                    if (blue < 255)

                    {
                        (dataPtr + 0 * m.widthStep + x * nChan)[0] = (byte)blue;
                    }

                    else if (blue >= 255)
                    {
                        (dataPtr + 0 * m.widthStep + x * nChan)[0] = 255;
                    }

                    if (green < 255)
                    {
                        (dataPtr + 0 * m.widthStep + x * nChan)[1] = (byte)green;
                    }

                    else if (green >= 255)
                    {
                        (dataPtr + 0 * m.widthStep + x * nChan)[1] = 255;
                    }

                    if (red < 255)
                    {
                        (dataPtr + 0 * m.widthStep + x * nChan)[2] = (byte)red;
                    }

                    else if (red >= 255)
                    {
                        (dataPtr + 0 * m.widthStep + x * nChan)[2] = 255;
                    }
                }

                //Margem inferior sem cantos
                for (x = 1; x < (width - 1); x++)
                {
                    //cálculo da média na compenente azul para um filtro 3x3
                    SXblue = (int)Math.Round((double)((1 + 2) * (copyPtr + (height - 1) * mcopy.widthStep + (x - 1) * nChan)[0] + 1 * (copyPtr + (height - 2) * mcopy.widthStep + (x - 1) * nChan)[0] +
                        (0 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + x * nChan)[0] + 0 * (copyPtr + (height - 2) * mcopy.widthStep + (x) * nChan)[0] +
                        (-1 + -2) * (copyPtr + (height - 1) * mcopy.widthStep + (x + 1) * nChan)[0] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (x + 1) * nChan)[0]) / 1);

                    //cálculo da média na compenente verde para um filtro 3x3
                    SXgreen = (int)Math.Round((double)((1 + 2) * (copyPtr + (height - 1) * mcopy.widthStep + (x - 1) * nChan)[1] + 1 * (copyPtr + (height - 2) * mcopy.widthStep + (x - 1) * nChan)[1] +
                        (0 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + x * nChan)[1] + 0 * (copyPtr + (height - 2) * mcopy.widthStep + (x) * nChan)[1] +
                        (-1 + -2) * (copyPtr + (height - 1) * mcopy.widthStep + (x + 1) * nChan)[1] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (x + 1) * nChan)[1]) / 1);

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    SXred = (int)Math.Round((double)((1 + 2) * (copyPtr + (height - 1) * mcopy.widthStep + (x - 1) * nChan)[2] + 1 * (copyPtr + (height - 2) * mcopy.widthStep + (x - 1) * nChan)[2] +
                        (0 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + x * nChan)[2] + 0 * (copyPtr + (height - 2) * mcopy.widthStep + (x) * nChan)[2] +
                        (-1 + -2) * (copyPtr + (height - 1) * mcopy.widthStep + (x + 1) * nChan)[2] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (x + 1) * nChan)[2]) / 1);

                    //cálculo da média na compenente azul para um filtro 3x3
                    SYblue = (int)Math.Round((double)((1 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (x - 1) * nChan)[0] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (x - 1) * nChan)[0] +
                        (2 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + x * nChan)[0] + -2 * (copyPtr + (height - 2) * mcopy.widthStep + (x) * nChan)[0] +
                        (1 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (x + 1) * nChan)[0] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (x + 1) * nChan)[0]) / 1);

                    //cálculo da média na compenente verde para um filtro 3x3
                    SYgreen = (int)Math.Round((double)((1 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (x - 1) * nChan)[1] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (x - 1) * nChan)[1] +
                        (2 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + x * nChan)[1] + -2 * (copyPtr + (height - 2) * mcopy.widthStep + (x) * nChan)[1] +
                        (1 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (x + 1) * nChan)[1] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (x + 1) * nChan)[1]) / 1);

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    SYred = (int)Math.Round((double)((1 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (x - 1) * nChan)[2] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (x - 1) * nChan)[2] +
                        (2 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + x * nChan)[2] + -2 * (copyPtr + (height - 2) * mcopy.widthStep + (x) * nChan)[2] +
                        (1 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (x + 1) * nChan)[2] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (x + 1) * nChan)[2]) / 1);

                    blue = Math.Abs(SXblue) + Math.Abs(SYblue);
                    green = Math.Abs(SXgreen) + Math.Abs(SYgreen);
                    red = Math.Abs(SXred) + Math.Abs(SYred);

                    if (blue < 255)

                    {
                        (dataPtr + (height - 1) * m.widthStep + x * nChan)[0] = (byte)blue;
                    }

                    else if (blue >= 255)
                    {
                        (dataPtr + (height - 1) * m.widthStep + x * nChan)[0] = 255;
                    }

                    if (green < 255)
                    {
                        (dataPtr + (height - 1) * m.widthStep + x * nChan)[1] = (byte)green;
                    }

                    else if (green >= 255)
                    {
                        (dataPtr + (height - 1) * m.widthStep + x * nChan)[1] = 255;
                    }

                    if (red < 255)
                    {
                        (dataPtr + (height - 1) * m.widthStep + x * nChan)[2] = (byte)red;
                    }

                    else if (red >= 255)
                    {
                        (dataPtr + (height - 1) * m.widthStep + x * nChan)[2] = 255;
                    }
                }

                //Canto Superior Esquerdo

                //cálculo da média na compenente azul para um filtro 3x3
                SXblue = (int)Math.Round((double)((1 + 0 + 2 + 0) * (copyPtr + (0) * mcopy.widthStep + (0) * nChan)[0] +
                    (-1 + -2) * (copyPtr + (0) * mcopy.widthStep + 1 * nChan)[0] +
                    (1 + 0) * (copyPtr + (1) * mcopy.widthStep + (0) * nChan)[0] + -1 * (copyPtr + (1) * mcopy.widthStep + (1) * nChan)[0]) / 1);

                //cálculo da média na compenente verde para um filtro 3x3
                SXgreen = (int)Math.Round((double)((1 + 0 + 2 + 0) * (copyPtr + (0) * mcopy.widthStep + (0) * nChan)[1] +
                    (-1 + -2) * (copyPtr + (0) * mcopy.widthStep + 1 * nChan)[1] +
                    (1 + 0) * (copyPtr + (1) * mcopy.widthStep + (0) * nChan)[1] + -1 * (copyPtr + (1) * mcopy.widthStep + (1) * nChan)[1]) / 1);

                //cálculo da média na compenente vermelha para um filtro 3x3
                SXred = (int)Math.Round((double)((1 + 0 + 2 + 0) * (copyPtr + (0) * mcopy.widthStep + (0) * nChan)[2] +
                    (-1 + -2) * (copyPtr + (0) * mcopy.widthStep + 1 * nChan)[2] +
                    (1 + 0) * (copyPtr + (1) * mcopy.widthStep + (0) * nChan)[2] + -1 * (copyPtr + (1) * mcopy.widthStep + (1) * nChan)[2]) / 1);

                //cálculo da média na compenente azul para um filtro 3x3
                SYblue = (int)Math.Round((double)((-1 + 0 + -2 + 0) * (copyPtr + (0) * mcopy.widthStep + (0) * nChan)[0] +
                    (-1 + 0) * (copyPtr + (0) * mcopy.widthStep + 1 * nChan)[0] +
                    (1 + 2) * (copyPtr + (1) * mcopy.widthStep + (0) * nChan)[0] + 1 * (copyPtr + (1) * mcopy.widthStep + (1) * nChan)[0]) / 1);

                //cálculo da média na compenente verde para um filtro 3x3
                SYgreen = (int)Math.Round((double)((-1 + 0 + -2 + 0) * (copyPtr + (0) * mcopy.widthStep + (0) * nChan)[1] +
                    (-1 + 0) * (copyPtr + (0) * mcopy.widthStep + 1 * nChan)[1] +
                    (1 + 2) * (copyPtr + (1) * mcopy.widthStep + (0) * nChan)[1] + 1 * (copyPtr + (1) * mcopy.widthStep + (1) * nChan)[1]) / 1);

                //cálculo da média na compenente vermelha para um filtro 3x3
                SYred = (int)Math.Round((double)((-1 + 0 + -2 + 0) * (copyPtr + (0) * mcopy.widthStep + (0) * nChan)[2] +
                    (-1 + 0) * (copyPtr + (0) * mcopy.widthStep + 1 * nChan)[2] +
                    (1 + 2) * (copyPtr + (1) * mcopy.widthStep + (0) * nChan)[2] + 1 * (copyPtr + (1) * mcopy.widthStep + (1) * nChan)[2]) / 1);

                blue = Math.Abs(SXblue) + Math.Abs(SYblue);
                green = Math.Abs(SXgreen) + Math.Abs(SYgreen);
                red = Math.Abs(SXred) + Math.Abs(SYred);

                if (blue < 255)

                {
                    (dataPtr + 0 * m.widthStep + 0 * nChan)[0] = (byte)blue;
                }

                else if (blue >= 255)
                {
                    (dataPtr + 0 * m.widthStep + 0 * nChan)[0] = 255;
                }

                if (green < 255)
                {
                    (dataPtr + 0 * m.widthStep + 0 * nChan)[1] = (byte)green;
                }

                else if (green >= 255)
                {
                    (dataPtr + 0 * m.widthStep + 0 * nChan)[1] = 255;
                }

                if (red < 255)
                {
                    (dataPtr + 0 * m.widthStep + 0 * nChan)[2] = (byte)red;
                }

                else if (red >= 255)
                {
                    (dataPtr + 0 * m.widthStep + 0 * nChan)[2] = 255;
                }


                //Canto Superior Direito

                //cálculo da média na compenente azul para um filtro 3x3
                SXblue = (int)Math.Round((double)((-3) * (copyPtr + (width - 1) * nChan)[0] +
                    3 * (copyPtr + (width - 2) * nChan)[0] +
                    (-1) * (copyPtr + mcopy.widthStep + (width - 1) * nChan)[0] + (copyPtr + mcopy.widthStep + (width - 2) * nChan)[0]));

                //cálculo da média na compenente verde para um filtro 3x3
                SXgreen = (int)Math.Round((double)((-3) * (copyPtr + (width - 1) * nChan)[1] +
                    3 * (copyPtr + (width - 2) * nChan)[1] +
                    (-1) * (copyPtr + mcopy.widthStep + (width - 1) * nChan)[1] + (copyPtr + mcopy.widthStep + (width - 2) * nChan)[1]));

                //cálculo da média na compenente vermelha para um filtro 3x3
                SXred = (int)Math.Round((double)((-3) * (copyPtr + (width - 1) * nChan)[2] +
                    3 * (copyPtr + (width - 2) * nChan)[2] +
                    (-1) * (copyPtr + mcopy.widthStep + (width - 1) * nChan)[2] + (copyPtr + mcopy.widthStep + (width - 2) * nChan)[2]));

                //cálculo da média na compenente azul para um filtro 3x3
                SYblue = (int)Math.Round((double)((-3) * (copyPtr + (width - 1) * nChan)[0] +
                    (-1) * (copyPtr + (width - 2) * nChan)[0] +
                    (3) * (copyPtr + mcopy.widthStep + (width - 1) * nChan)[0] + (copyPtr + mcopy.widthStep + (width - 2) * nChan)[0]));

                //cálculo da média na compenente verde para um filtro 3x3
                SYgreen = (int)Math.Round((double)((-3) * (copyPtr + (width - 1) * nChan)[1] +
                    (-1) * (copyPtr + (width - 2) * nChan)[1] +
                    (3) * (copyPtr + mcopy.widthStep + (width - 1) * nChan)[1] + (copyPtr + mcopy.widthStep + (width - 2) * nChan)[1]));

                //cálculo da média na compenente vermelha para um filtro 3x3
                SYred = (int)Math.Round((double)((-3) * (copyPtr + (width - 1) * nChan)[2] +
                    (-1) * (copyPtr + (width - 2) * nChan)[2] +
                    (3) * (copyPtr + mcopy.widthStep + (width - 1) * nChan)[2] + (copyPtr + mcopy.widthStep + (width - 2) * nChan)[2]));

                blue = Math.Abs(SXblue) + Math.Abs(SYblue);
                green = Math.Abs(SXgreen) + Math.Abs(SYgreen);
                red = Math.Abs(SXred) + Math.Abs(SYred);
                
                if (blue > 255)

                {
                    blue = 255;
                }

                (dataPtr + 0 * m.widthStep + (width - 1) * nChan)[0] = (byte)blue;

                if (green > 255)
                {
                    green = 255;
                }

                (dataPtr + 0 * m.widthStep + (width - 1) * nChan)[1] = (byte)green;

                if (red > 255)
                {
                    red = 255;
                }

                (dataPtr + 0 * m.widthStep + (width - 1) * nChan)[2] = (byte)red;

                //Canto Inferior Esquerdo

                //cálculo da média na compenente azul para um filtro 3x3
                SXblue = (int)Math.Round((double)((1 + 2 + 0 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (0) * nChan)[0] +
                    (-1 + -2) * (copyPtr + (height - 1) * mcopy.widthStep + (1) * nChan)[0] +
                    (1 + 0) * (copyPtr + (height - 2) * mcopy.widthStep + (0) * nChan)[0] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (1) * nChan)[0]) / 1);

                //cálculo da média na compenente verde para um filtro 3x3
                SXgreen = (int)Math.Round((double)((1 + 2 + 0 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (0) * nChan)[1] +
                    (-1 + -2) * (copyPtr + (height - 1) * mcopy.widthStep + (1) * nChan)[1] +
                    (1 + 0) * (copyPtr + (height - 2) * mcopy.widthStep + (0) * nChan)[1] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (1) * nChan)[1]) / 1);

                //cálculo da média na compenente vermelha para um filtro 3x3
                SXred = (int)Math.Round((double)((1 + 2 + 0 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (0) * nChan)[2] +
                    (-1 + -2) * (copyPtr + (height - 1) * mcopy.widthStep + (1) * nChan)[2] +
                    (1 + 0) * (copyPtr + (height - 2) * mcopy.widthStep + (0) * nChan)[2] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (1) * nChan)[2]) / 1);

                //cálculo da média na compenente azul para um filtro 3x3
                SYblue = (int)Math.Round((double)((1 + 2 + 0 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (0) * nChan)[0] +
                    (1 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (1) * nChan)[0] +
                    (-2 + -1) * (copyPtr + (height - 2) * mcopy.widthStep + (0) * nChan)[0] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (1) * nChan)[0]) / 1);

                //cálculo da média na compenente verde para um filtro 3x3
                SYgreen = (int)Math.Round((double)((1 + 2 + 0 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (0) * nChan)[1] +
                    (1 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (1) * nChan)[1] +
                    (-2 + -1) * (copyPtr + (height - 2) * mcopy.widthStep + (0) * nChan)[1] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (1) * nChan)[1]) / 1);

                //cálculo da média na compenente vermelha para um filtro 3x3
                SYred = (int)Math.Round((double)((1 + 2 + 0 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (0) * nChan)[2] +
                    (1 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (1) * nChan)[2] +
                    (-2 + -1) * (copyPtr + (height - 2) * mcopy.widthStep + (0) * nChan)[2] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (1) * nChan)[2]) / 1);

                blue = Math.Abs(SXblue) + Math.Abs(SYblue);
                green = Math.Abs(SXgreen) + Math.Abs(SYgreen);
                red = Math.Abs(SXred) + Math.Abs(SYred);

                if (blue < 255)

                {
                    (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[0] = (byte)blue;
                }

                else if (blue >= 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[0] = 255;
                }

                if (green < 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[1] = (byte)green;
                }

                else if (green >= 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[1] = 255;
                }

                if (red < 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[2] = (byte)red;
                }

                else if (red >= 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + 0 * nChan)[2] = 255;
                }

                //Canto Inferior Direito

                //cálculo da média na compenente azul para um filtro 3x3
                SXblue = (int)Math.Round((double)((0 + 0 + -2 + -1) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 1) * nChan)[0] +
                    (2 + 1) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 2) * nChan)[0] +
                    (0 + -1) * (copyPtr + (height - 2) * mcopy.widthStep + (width - 1) * nChan)[0] + 1 * (copyPtr + (height - 2) * mcopy.widthStep + (width - 2) * nChan)[0]) / 1);

                //cálculo da média na compenente verde para um filtro 3x3
                SXgreen = (int)Math.Round((double)((0 + 0 + -2 + -1) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 1) * nChan)[1] +
                    (2 + 1) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 2) * nChan)[1] +
                    (0 + -1) * (copyPtr + (height - 2) * mcopy.widthStep + (width - 1) * nChan)[1] + 1 * (copyPtr + (height - 2) * mcopy.widthStep + (width - 2) * nChan)[1]) / 1);

                //cálculo da média na compenente vermelha para um filtro 3x3
                SXred = (int)Math.Round((double)((0 + 0 + -2 + -1) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 1) * nChan)[2] +
                    (2 + 1) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 2) * nChan)[2] +
                    (0 + -1) * (copyPtr + (height - 2) * mcopy.widthStep + (width - 1) * nChan)[2] + 1 * (copyPtr + (height - 2) * mcopy.widthStep + (width - 2) * nChan)[2]) / 1);

                //cálculo da média na compenente azul para um filtro 3x3
                SYblue = (int)Math.Round((double)((0 + 0 + 2 + 1) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 1) * nChan)[0] +
                    (1 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 2) * nChan)[0] +
                    (-2 + -1) * (copyPtr + (height - 2) * mcopy.widthStep + (width - 1) * nChan)[0] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (width - 2) * nChan)[0]) / 1);

                //cálculo da média na compenente verde para um filtro 3x3
                SYgreen = (int)Math.Round((double)(((0 + 0 + 2 + 1) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 1) * nChan)[1] +
                    (1 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 2) * nChan)[1] +
                    (-2 + -1) * (copyPtr + (height - 2) * mcopy.widthStep + (width - 1) * nChan)[1] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (width - 2) * nChan)[1]) / 1));

                //cálculo da média na compenente vermelha para um filtro 3x3
                SYred = (int)Math.Round((double)((0 + 0 + 2 + 1) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 1) * nChan)[2] +
                    (1 + 0) * (copyPtr + (height - 1) * mcopy.widthStep + (width - 2) * nChan)[2] +
                    (-2 + -1) * (copyPtr + (height - 2) * mcopy.widthStep + (width - 1) * nChan)[2] + -1 * (copyPtr + (height - 2) * mcopy.widthStep + (width - 2) * nChan)[2]) / 1);

                blue = Math.Abs(SXblue) + Math.Abs(SYblue);
                green = Math.Abs(SXgreen) + Math.Abs(SYgreen);
                red = Math.Abs(SXred) + Math.Abs(SYred);

                if (blue < 255)

                {
                    (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[0] = (byte)blue;
                }

                else if (blue >= 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[0] = 255;
                }

                if (green < 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[1] = (byte)green;
                }

                else if (green >= 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[1] = 255;
                }

                if (red < 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[2] = (byte)red;
                }

                else if (red >= 255)
                {
                    (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[2] = 255;
                }
            
            }
        }

        public static void Diferentiation(Image<Bgr, byte> img, Image<Bgr, byte> imgCopy)
        {
            unsafe
            {
                MIplImage m = img.MIplImage;
                MIplImage mcopy = imgCopy.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer();
                byte* copyPtr = (byte*)mcopy.imageData.ToPointer();
                int blue, green, red;
                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels;
                int x, y;

                for (y = 0; y < (height - 1); y++)
                {
                    for (x = 0; x < (width - 1); x++)
                    {
                        //cálculo da média na compenente azul para um filtro 3x3
                        blue = (int)Math.Round((double)(Math.Abs((copyPtr + (y) * mcopy.widthStep + (x) * nChan)[0] - (copyPtr + (y+1) * mcopy.widthStep + (x) * nChan)[0]) +
                            Math.Abs((copyPtr + (y) * mcopy.widthStep + (x) * nChan)[0] - (copyPtr + (y) * mcopy.widthStep + (x + 1) * nChan)[0])
                            ));

                        //cálculo da média na compenente verde para um filtro 3x3
                        green = (int)Math.Round((double)(Math.Abs((copyPtr + (y) * mcopy.widthStep + (x) * nChan)[1] - (copyPtr + (y + 1) * mcopy.widthStep + (x) * nChan)[1]) +
                            Math.Abs((copyPtr + (y) * mcopy.widthStep + (x) * nChan)[1] - (copyPtr + (y) * mcopy.widthStep + (x + 1) * nChan)[1])
                            ));

                        //cálculo da média na compenente vermelha para um filtro 3x3
                        red = (int)Math.Round((double)(Math.Abs((copyPtr + (y) * mcopy.widthStep + (x) * nChan)[2] - (copyPtr + (y + 1) * mcopy.widthStep + (x) * nChan)[2]) +
                            Math.Abs((copyPtr + (y) * mcopy.widthStep + (x) * nChan)[2] - (copyPtr + (y) * mcopy.widthStep + (x + 1) * nChan)[2])
                            ));

                        if (blue < 255)

                        {
                            (dataPtr + y * m.widthStep + x * nChan)[0] = (byte)blue;
                        }

                        else if (blue >= 255)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[0] = 255;
                        }

                        if (green < 255)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[1] = (byte)green;
                        }

                        else if (green >= 255)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[1] = 255;
                        }

                        if (red < 255)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[2] = (byte)red;
                        }

                        else if (red >= 255)
                        {
                            (dataPtr + y * m.widthStep + x * nChan)[2] = 255;
                        }
                    }
                }

                //Margem direita sem canto inferior direito
                for (y = 0; y < (height - 1); y++)
                {
                    //cálculo da média na compenente azul para um filtro 3x3
                    blue = (int)Math.Round((double)(Math.Abs((copyPtr + (y) * mcopy.widthStep + (width-1) * nChan)[0] - (copyPtr + (y + 1) * mcopy.widthStep + (width - 1) * nChan)[0])
                        ));

                    //cálculo da média na compenente verde para um filtro 3x3
                    green = (int)Math.Round((double)(Math.Abs((copyPtr + (y) * mcopy.widthStep + (width - 1) * nChan)[1] - (copyPtr + (y + 1) * mcopy.widthStep + (width - 1) * nChan)[1])
                        ));

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    red = (int)Math.Round((double)(Math.Abs((copyPtr + (y) * mcopy.widthStep + (width - 1) * nChan)[2] - (copyPtr + (y + 1) * mcopy.widthStep + (width - 1) * nChan)[2])
                        ));

                    if (blue < 255)

                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[0] = (byte)blue;
                    }

                    else if (blue >= 255)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[0] = 255;
                    }

                    if (green < 255)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[1] = (byte)green;
                    }

                    else if (green >= 255)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[1] = 255;
                    }

                    if (red < 255)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[2] = (byte)red;
                    }

                    else if (red >= 255)
                    {
                        (dataPtr + y * m.widthStep + (width - 1) * nChan)[2] = 255;
                    }
                }

                //Margem inferior sem canto inferior direito
                for (x = 0; x < (width - 1); x++)
                {
                    //cálculo da média na compenente azul para um filtro 3x3
                    blue = (int)Math.Round((double)(Math.Abs((copyPtr + (height - 1) * mcopy.widthStep + (x) * nChan)[0] - (copyPtr + (height - 1) * mcopy.widthStep + (x + 1) * nChan)[0])
                        ));

                    //cálculo da média na compenente verde para um filtro 3x3
                    green = (int)Math.Round((double)(Math.Abs((copyPtr + (height - 1) * mcopy.widthStep + (x) * nChan)[1] - (copyPtr + (height - 1) * mcopy.widthStep + (x + 1) * nChan)[1])
                        ));

                    //cálculo da média na compenente vermelha para um filtro 3x3
                    red = (int)Math.Round((double)(Math.Abs((copyPtr + (height - 1) * mcopy.widthStep + (x) * nChan)[2] - (copyPtr + (height - 1) * mcopy.widthStep + (x + 1) * nChan)[2])
                        ));

                    if (blue > 255)

                    {
                        blue = 255;
                    }

                    (dataPtr + (height - 1) * m.widthStep + x * nChan)[0] = (byte)blue;

                    if (green > 255)
                    {
                        green = 255;
                    }

                    (dataPtr + (height - 1) * m.widthStep + x * nChan)[1] = (byte)green;
                    
                    if (red > 255)
                    {
                        red = 255;
                    }

                    (dataPtr + (height - 1) * m.widthStep + x * nChan)[2] = (byte)red;

                }

                //Canto inferior direito

                (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[0] = (byte)0;
                (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[1] = (byte)0;
                (dataPtr + (height - 1) * m.widthStep + (width - 1) * nChan)[2] = (byte)0;
            }
        }

        public static void Median(Image<Bgr, byte> img, Image<Bgr, byte> imgCopy)
        {

            imgCopy.SmoothMedian(3).CopyTo(img);

        }

        public static int[] Histogram_Gray(Emgu.CV.Image<Bgr, byte> img)
        {
            /*unsafe
            {
                MIplImage m = img.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer();
                byte blue, green, red;
                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels;
                int npi = width * height;
                int x, y, gray, i=0;
                int[] histogram = new int[npi];

                for (y = 0; y < height; y++)
                    {
                        for (x = 0; x < width; x++)
                            {
                                blue = (dataPtr + y * m.widthStep + x * nChan)[0];
                                green = (dataPtr + y * m.widthStep + x * nChan)[1];
                                red = (dataPtr + y * m.widthStep + x * nChan)[2];

                                gray = (blue + green + red) / 3;

                                histogram[i] = gray;
                                i += 1;

                            }
                    }

                return histogram;
            }*/

            {
                unsafe
                {
                    // direct access to the image memory(sequencial)
                    // direcion top left -> bottom right

                    MIplImage m = img.MIplImage;
                    byte* dataPtr = (byte*)m.imageData.ToPointer(); // Pointer to the image

                    int width = img.Width;
                    int height = img.Height;
                    int nChan = m.nChannels; // number of channels - 3
                    int widthStep = m.widthStep;

                    int[] hist = new int[256];
                    int blue, green, red;

                    if (nChan == 3) // image in RGB
                    {

                        // obter apontador do inicio da imagem MIplImage m = img.MIplImage; byte* dataPtr = (byte*)m.imageData.ToPointer();
                        for (int y = 0; y < height; y++)
                        {
                            for (int x = 0; x < width; x++)
                            { // calcula endereço do pixel no ponto (x,y)

                                blue = (dataPtr + y * widthStep + x * nChan)[0];
                                green = (dataPtr + y * widthStep + x * nChan)[1];
                                red = (dataPtr + y * widthStep + x * nChan)[2];

                                hist[(int)Math.Round((blue + green + red) / 3.0)] += 1;
                            }
                        }
                    }
                    return hist;
                }

            }
        }

        public static void ConvertToBW(Emgu.CV.Image<Bgr, byte> img, int threshold)
        {
            unsafe
            {
                MIplImage m = img.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer();
                byte blue, green, red;
                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels;
                int npi = width * height;
                int x, y, gray, i = 0;

                for (y = 0; y < height; y++)
                {
                    for (x = 0; x < width; x++)
                    {
                        blue = (dataPtr + y * m.widthStep + x * nChan)[0];
                        green = (dataPtr + y * m.widthStep + x * nChan)[1];
                        red = (dataPtr + y * m.widthStep + x * nChan)[2];

                        gray = (int)Math.Round((blue + green + red) / 3.0);

                        if (gray >= threshold)
                        {
                            gray = 255;
                        }

                        else
                        {
                            gray = 0;
                        }

                        (dataPtr + y * m.widthStep + x * nChan)[0]=(byte)gray;
                        (dataPtr + y * m.widthStep + x * nChan)[1] = (byte)gray;
                        (dataPtr + y * m.widthStep + x * nChan)[2] = (byte)gray;
                    }
                }

            }

        }

        public static void ConvertToBW_Otsu(Emgu.CV.Image<Bgr, byte> img)
        {
            unsafe
            {

                int total = 0;
                int[] histogram = Histogram_Gray(img);
                double[] Phistogram = new double[256];
                
                /*for (int i=0; i<=255; i++)
                {
                    total += histogram[i];
                }
                
                for (int i = 0; i <= 255; i++)
                {
                    Phistogram[i] = (double)histogram[i]/total;
                }
                
                double q1 = Phistogram[0];
                double q2 = 1 - q1;

                double u1 = 0;
                double u2 = 0;

                double max = 0;
                int threshold = 1;

                for (int i=1; i<=255; i++)
                {
                    u2 += i * Phistogram[i];
                }

                double var = q1 * q2 * Math.Pow((u1 - u2/q2), 2);

                for (int t=1; t<256; t++)
                {

                    if (var >= max)
                    {
                        max = var;
                        threshold = t;
                    }

                    q1 += Phistogram[t];
                    q2 = 1 - q1;
                    u1 += t * Phistogram[t];
                    u2 -= t * Phistogram[t];
                    var = q1 * q2 * Math.Pow((u1/q1 - u2/q2), 2);

                }*/
                
                
                for (int i=0; i<=255; i++)
                {
                    total += histogram[i];
                }
                
                
                double q1 = histogram[0];
                double q2 = total - q1;

                double u1 = 0;
                double u2 = 0;

                double max = 0;
                int threshold = 1;

                for (int i=1; i<=255; i++)
                {
                    u2 += i * histogram[i];
                }

                double var = q1 * q2 * Math.Pow((u1 - u2/q2), 2);

                for (int t=1; t<256; t++)
                {

                    if (var >= max)
                    {
                        max = var;
                        threshold = t;
                    }

                    q1 += histogram[t];
                    q2 -= histogram[t];
                    u1 += t * histogram[t];
                    u2 -= t * histogram[t];
                    var = q1 * q2 * Math.Pow(((u1/q1 - u2/q2)), 2);

                }
                

                ConvertToBW(img, threshold);
            }
        }


    }
}


/*public static int[,] Histogram_RGB(Emgu.CV.Image<Bgr, byte> img)
        {
            unsafe
            {
                // direct access to the image memory(sequencial)
                // direcion top left -> bottom right

                MIplImage m = img.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer(); // Pointer to the image

                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels; // number of channels - 3
                int widthStep = m.widthStep;

                int[,] hist = new int[3,256];

                int blue, green, red;

                if (nChan == 3) // image in RGB
                {

                    // obter apontador do inicio da imagem MIplImage m = img.MIplImage; byte* dataPtr = (byte*)m.imageData.ToPointer();
                    for (int y = 0; y < height; y++)
                    {
                        for (int x = 0; x < width; x++)
                        { // calcula endereço do pixel no ponto (x,y)

                            blue = (dataPtr + y * widthStep + x * nChan)[0];
                            green = (dataPtr + y * widthStep + x * nChan)[1];
                            red = (dataPtr + y * widthStep + x * nChan)[2];

                            hist[0, blue] += 1;
                            hist[1, green] += 1;
                            hist[2, red] += 1;
                        }
                    }
                }
                return hist;
            }
        }


        public static int[,] Histogram_All(Emgu.CV.Image<Bgr, byte> img)
        {
            unsafe
            {
                // direct access to the image memory(sequencial)
                // direcion top left -> bottom right

                MIplImage m = img.MIplImage;
                byte* dataPtr = (byte*)m.imageData.ToPointer(); // Pointer to the image

                int width = img.Width;
                int height = img.Height;
                int nChan = m.nChannels; // number of channels - 3
                int widthStep = m.widthStep;

                int[,] hist = new int[4, 256];

                int blue, green, red;

                if (nChan == 3) // image in RGB
                {

                    // obter apontador do inicio da imagem MIplImage m = img.MIplImage; byte* dataPtr = (byte*)m.imageData.ToPointer();
                    for (int y = 0; y < height; y++)
                    {
                        for (int x = 0; x < width; x++)
                        { // calcula endereço do pixel no ponto (x,y)

                            blue = (dataPtr + y * widthStep + x * nChan)[0];
                            green = (dataPtr + y * widthStep + x * nChan)[1];
                            red = (dataPtr + y * widthStep + x * nChan)[2];

                            hist[0,(int)Math.Round((blue + green + red) / 3.0)] += 1;
                            hist[1, blue] += 1;
                            hist[2, green] += 1;
                            hist[3, red] += 1;
                        }
                    }
                }
                return hist;
            }
        }*/
